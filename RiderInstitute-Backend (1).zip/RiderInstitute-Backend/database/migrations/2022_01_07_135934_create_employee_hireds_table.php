<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateEmployeeHiredsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('employee_hireds', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('employee_id');
            $table->foreign('employee_id')->references('id')->on('users');
            $table->unsignedBigInteger('employer_id');
            $table->foreign('employer_id')->references('id')->on('users');
            $table->longText('reason_by_employer')->nullable();
            $table->longText('reason_by_employee')->nullable();
            $table->boolean('termination_by_employer')->nullable()->default(0);
            $table->boolean('termination_by_employee')->nullable()->default(0);
            $table->tinyText('status');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('employee_hireds');
    }
}
