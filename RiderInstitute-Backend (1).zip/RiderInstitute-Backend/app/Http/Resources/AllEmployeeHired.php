<?php

namespace App\Http\Resources;

use App\Models\Employee;
use App\Models\User;
use Illuminate\Http\Resources\Json\JsonResource;

class AllEmployeeHired extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        return [
            "id"=>$this->id,
            "name"=>$this->name,
            "role"=>$this->role,
            "picture"=>User::where(["id"=>$this->user_id])->first()->picture??"",
            "email"=>User::where(["id"=>$this->user_id])->first()->email??"",
            "verified"=>User::where(["id"=>$this->user_id])->first()->is_verified??"",
            "user_id"=>User::where(["id"=>$this->user_id])->first()->id??"",
            "nin_slip"=>$this->nin_slip,
            "rider_card"=>$this->rider_card,
            "driving_license"=>$this->driving_license,
            "prove_of_address"=>$this->prove_of_address,
            "passport_photograph"=>$this->passport_photograph,
            "nin_slipld"=>$this->nin_slipld,
            "rider_cardId"=>$this->rider_cardId,
            "driving_licenseId"=>$this->driving_licenseId,
            "prove_of_addressId"=>$this->prove_of_addressId,
            "passport_photographId"=>$this->passport_photographId,
            "approved_by_ri"=>$this->approved_by_ri,
            "nin_slippage"=>$this->nin_slippage,
            "rider_cardpage"=>$this->rider_cardpage,
            "driving_licensepage"=>$this->driving_licensepage,
            "prove_of_addresspage"=>$this->prove_of_addresspage,
            "passport_photographpage"=>$this->passport_photographpage

            // "explaination"=>$this->explaination,
        ];
    }
}
