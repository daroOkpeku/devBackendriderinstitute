<?php

namespace App\Http\Resources;

use App\Models\Employer;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Http\Resources\Json\JsonResource;

class EmployeeHiredexit extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        return [
            "id"=>$this->id,
            // "employee_id": 3,
            // "employer_id": 1,
            "reason_by_employer"=>$this->reason_by_employer,
            "status"=>$this->status,
             "employer_name"=>Employer::where(['user_id'=>$this->employer_id])->first()->Company_Name??"",
                // ''stat=>Carbon::createFromFormat('Y-m-d H:i:s', $this->created_at),
            // "date_started"=>Carbon::parse($this->date_started)->format('Y-m-d'),
            // "end_data"=>Carbon::parse($this->end_data)->format('Y-m-d'),
            "date_started"=>$this->date_started,
             "end_data"=>$this->end_data,
            "recommend_candiate"=>$this->recommend_candiate,
            "employe_candiate_again"=>$this->employe_candiate_again
        ];
    }
}
