<?php

namespace App\Http\Resources;

use Carbon\Carbon;
use Illuminate\Http\Resources\Json\JsonResource;

class Paymenthis extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        return [
            "created_at"=>$this->created_at,
            "code"=>$this->referencecode,
            "subscription"=>$this->subscription,
            "verification"=>$this->verificationmessage,
            "id"=>$this->id,
            'created'=>$this->updated_at,
        ];
    }
}
