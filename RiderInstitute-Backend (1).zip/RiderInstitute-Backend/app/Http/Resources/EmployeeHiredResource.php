<?php

namespace App\Http\Resources;

use App\Models\Employee;
use App\Models\User;
use App\Models\AppliedJob;
use Illuminate\Http\Resources\Json\JsonResource;

class EmployeeHiredResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        return[

                    "id" => $this->id,
                    // "employee_id" => $this->employee_id,
                    // "employer_id" => $this->employer_id,
                    "reason_by_employer" => $this->reason_by_employer,
                    "reason_by_employee" => $this->reason_by_employee,
                    "termination_by_employer" => $this->termination_by_employer,
                    "termination_by_employee"=> $this->termination_by_employee,
                    "status"=>$this->status,
                    "created_at"=>$this->created_at,
                    "updated_at"=>$this->updated_at,
                    "posted_id"=>$this->posted_id,
                    "appliedid"=> AppliedJob::where(['user_id'=>$this->employee_id, 'employer_id'=>$this->employer_id])->first()->id??"",
                    "employee"=> Employee::where(['user_id'=>$this->employee_id])->first()??"",
                    "user"=>User::where(["id"=>$this->employee_id])->first()??"",
                    "explaination"=>$this->explaination,
                    "date_started"=>$this->date_started,
                    "end_data"=>$this->end_data

        ];
    }
}
