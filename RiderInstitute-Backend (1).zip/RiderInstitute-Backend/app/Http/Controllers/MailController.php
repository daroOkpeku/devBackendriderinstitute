<?php

namespace App\Http\Controllers;

use App\Mail\Qualified;
use App\Mail\RegisterEmail;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;

class MailController extends Controller
{
  public static function SendRegisterEmail($name, $email, $verification_code){
    $data = [
        'name'=>$name,
        'verification_code'=>$verification_code
       ];
       Mail::to($email)->send(new RegisterEmail($data));
  }


  public static function QualifiedEmployees($posted_id, $posted_jobtitle, $employee_email, $employee_name, $companyname,  $joblocation){
      $data = [
       'posted_id'=>$posted_id,
       'jobTite'=>$posted_jobtitle,
       'email'=>$employee_email,
       'name'=>$employee_name,
       'companyname'=>$companyname,
       'joblocation'=>$joblocation
      ];
      Mail::to($employee_email)->send(new Qualified($data));
  }
}
