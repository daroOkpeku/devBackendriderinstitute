<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Employee extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'phone_number',
        'email',
        'date_of_birth',
        'state',
        'lga',
        'user_id',
        'experience_length',
        'gender',
        'age',
        'role',
        'highest_degree',
        'skills',
        'experience',
        'nin_slip',
        'rider_card',
        'driving_license',
        'prove_of_address',
        'passport_photograph'
    ];


}
