<?php

use App\Http\Controllers\Admin;
use App\Http\Controllers\apiController;
use App\Http\Controllers\AuthorsController;
use App\Http\Controllers\EmployeeController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});
Route::post("sign_up", [apiController::class,'sign_up']);
Route::post("fillempty",[apiController::class,"fillempty"]);
Route::post("correctpassword", [apiController::class,"correctpassword"]);
Route::put("mail",[apiController::class,'mail']);
Route::post("/login", [apiController::class,'login']);
Route::post("adminregister", [Admin::class,"adminregister"]);
Route::post("adminlogin", [Admin::class,"adminlogin"]);
Route::get("jobsdetail/{id}/{title}", [apiController::class,'jobsdetail']);
Route::get("Testhelp", [apiController::class,'Testhelp']);
Route::get("displayplans", [apiController::class,'displayplans']);
Route::put("forgetpassword", [apiController::class,"forgetpassword"]);
Route::get("topjob", [apiController::class,"topjob"]);
 Route::get("lastestjob", [apiController::class,"lastestjob"]);

Route::middleware('auth:sanctum')->group( function(){
    Route::get("check_emloyer/{id}", [apiController::class,'check_emloyer']);
    Route::post("insert_employer", [apiController::class,'insert_employer']);
    Route::put("change_password", [apiController::class,'change_password']);
    Route::get("check_user_login/{name}", [apiController::class,'check_user_login']);
    Route::post("jobs", [apiController::class,'jobs']);
    Route::put("edit_posted_job", [apiController::class, 'edit_posted_job']);
    Route::get("data_jobs/{email}/{id}", [apiController::class,'data_jobs']);
    Route::get("paystack_verify/{ref}", [apiController::class,'paystack_verify']);
    Route::get("employerplan/{data}", [apiController::class,'employerplan']);
    Route::post("insertemployerplan", [apiController::class, 'insertemployerplan']);
    Route::get('employerwallet/{user}', [apiController::class, 'employerwallet']);
    Route::get('/employer_info/{id}', [apiController::class,'employer_info']);
    Route::post("/payment", [apiController::class,'payment']);
    Route::get("postedjob/{page}",[apiController::class,'postedjob']);
    Route::get("selecte_jobposted/{id}", [apiController::class,'selecte_jobposted']);
    Route::get('qulifield_rider/{posted_id}', [apiController::class,'qulifield_rider']);
     Route::get("/expiredpostedjob", [apiController::class,"expiredpostedjob"]);
    Route::get("/postedjobAwaitingApproval",[apiController::class,"postedjobAwaitingApproval"]);
    Route::get("postedjobindaft",[apiController::class,"postedjobindaft"]);
    // Route::post('walletcal',[apiController::class, 'walletcal']);
    //immdiatecharge searchpostedjob
    Route::post("searchpostedjob",[apiController::class,'searchpostedjob']);
    Route::get("walletaccount/{page}",[apiController::class,'walletaccount']);
    Route::get("resubscribe/{id}/{page}", [apiController::class,'resubscribe']);
    Route::get("allpayment", [apiController::class,'allpayment']);
    Route::post('immdiatecharge',[apiController::class,'immdiatecharge']);
    Route::post('practiceSearch', [apiController::class,'practiceSearch']);
    Route::get("postindate/{user}", [apiController::class, 'postindate']);
    Route::put("updatephone", [apiController::class,"updatephone"]);
    Route::put("changepassword",[apiController::class,"changepassword"]);
    Route::post("insertemployeedata",[EmployeeController::class,"insertemployeedata"]);
    Route::get("employeedata/{user}/{email}", [EmployeeController::class,"employeedata"]);
    Route::get("availablejobs/{page}", [EmployeeController::class,"availablejobs"]);
    Route::get("findjob/{id}", [EmployeeController::class,"findjob"]);
    Route::get("numberofemployeeapplied/{id}/{page}", [apiController::class,'numberofemployeeapplied']);
    Route::post("applyjob", [EmployeeController::class,"applyjob"]);
    Route::post("editemployeeprofile", [EmployeeController::class,"editemployeeprofile"]);
    Route::get("numberappliant/{page}", [apiController::class,"numberappliant"]);
    Route::get("postjobs/{id}", [apiController::class,"postjobs"]);
    Route::post("updateapplied", [apiController::class,"updateapplied"]);
    Route::get("stephentest", [EmployeeController::class,"stephentest"]);
    Route::post("approvedjobsposted",[Admin::class,"approvedjobsposted"]);
    Route::get("admincreate/{page}", [Admin::class,"admincreate"]);
    Route::get("activeemployee/{page}", [Admin::class,"activeemployee"]);
    Route::get("Inactiveemployee/{page}", [Admin::class,"Inactiveemployee"]);
    Route::get("totalemployer/{page}", [Admin::class,"totalemployer"]);
    Route::get("activeemployer/{page}", [Admin::class,"activeemployer"]);
   Route::get("InactiveEmployer/{page}", [Admin::class,"InactiveEmployer"]); 
   Route::get("activeadmin/{page}", [Admin::class,"activeadmin"]); 
   Route::get("countalldownloads", [apiController::class,"countalldownloads"]);
    Route::post("adminadduser", [Admin::class,"adminadduser"]);
    Route::put("adminuserupdate",[Admin::class,"adminuserupdate"]);
    Route::post("suspensedaccount",[Admin::class,"suspensedaccount"]);
    Route::get("allpostedtotal/{page}", [Admin::class, "allpostedtotal"]);
     Route::get("allpostedUnapproved/{page}", [Admin::class, "allpostedUnapproved"]);
    //appliedEmployee, Inactiveemployee activeadmin allpostedUnapproved allpostedUnapproved
       Route::get("allpostedApprovedJobs/{page}", [Admin::class, "allpostedApprovedJobs"]);
    Route::post("verificationinfo",[EmployeeController::class,"verificationinfo"]);
    Route::post("edituserinfo", [Admin::class,"edituserinfo"]);
    Route::get("allpostedjob", [Admin::class,"allpostedjob"]);
    Route::get('appliedEmployee/{id}', [EmployeeController::class,'appliedEmployee']);
    Route::post('insertemployerstatus', [apiController::class,'insertemployerstatus']);
    Route::get("employerworker",[apiController::class,"employerworker"]);
    Route::get("employeeapplied/{id}", [EmployeeController::class,"employeeapplied"]);
    Route::post('addemployee', [apiController::class,'addemployee']);
    Route::post("usertest", [apiController::class, "usertest"]);
    Route::post("adminhirestatus",[Admin::class,"adminhirestatus"]);
    Route::put("employeeverified",[Admin::class,"employeeverified"]);
    Route::put("termination",[apiController::class, "termination"]);
    Route::get("employeemoreinfo/{employer_id}/{employee_id}", [apiController::class,"employeemoreinfo"]);
    Route::post('changestatus', [apiController::class,'changestatus']);
    Route::get("verifieldusers",[Admin::class,"verifieldusers"]);
    Route::get("getallplans", [Admin::class,"getallplans"]);
    Route::put("plansbyedit", [Admin::class,"plansbyedit"]);
    Route::delete("plansbydelete", [Admin::class, "plansbydelete"]);
    Route::get('allemployeestatus/{user_id}/{posted_id}', [apiController::class,'allemployeestatus']);
    Route::post("exitreason",[Admin::class,"exitreason"]);
    Route::post("unapprovedjobsposted", [Admin::class, "unapprovedjobsposted"]);
    Route::get("getreason",[Admin::class,"getreason"]);
    Route::get("admintotals",[Admin::class, "admintotals"]);
    Route::get("employerexitreason",[apiController::class,"employerexitreason"]);
    Route::put("/admineditreason",[Admin::class,'admineditreason']);
    Route::post("newtest", [apiController::class,"newtest"]);
    Route::post("searchemployeedata", [apiController::class,"searchemployeedata"]);
    Route::post("upload", [apiController::class,'upload']);
    Route::post('logout', [apiController::class,'logout']);
    Route::post("plansbyadmin", [Admin::class, "plansbyadmin"]);
    Route::post("AdminDownload", [Admin::class, "AdminDownload"]);
    Route::get("AdminDownloadall", [Admin::class, "AdminDownloadall"]);
    Route::get("testavailablejobs", [EmployeeController::class, "testavailablejobs"]);
    Route::put("AdminDownloadEdit", [Admin::class, "AdminDownloadEdit"]);
    Route::delete("AdminDownloadDelete", [Admin::class, "AdminDownloadDelete"]);
    Route::put("updatesubdownload", [apiController::class, 'updatesubdownload']);
    Route::get("downloadall", [apiController::class, "downloadall"]);
    Route::post("downloadcalculation", [apiController::class, 'downloadcalculation']);
    Route::post("paymentdownload", [apiController::class, 'paymentdownload']);
    Route::get("getallEmployerplans", [apiController::class, "getallEmployerplans"]);
    Route::get("subscriptiondownload", [apiController::class, 'subscriptiondownload']);
});

//
// 1000 = 2000 credit each job posting is connected to a plan,if the plan get expired
// 2000 = 3000 credit
// 400= = 4000 credit



// a subcription is linked to a credt plan which last for some days
// for example gotv subscription
// junja, jolli, max and smallie

// when i post a job it subtract the credit from mine subscription wallet
