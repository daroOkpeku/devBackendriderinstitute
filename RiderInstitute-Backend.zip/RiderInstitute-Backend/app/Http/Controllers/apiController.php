<?php

namespace App\Http\Controllers;
use Carbon\Carbon;
use Helpers\Helper;
use App\Models\User;
use App\Models\Rider;
use App\Models\Payment;
use App\Models\Employer;
use App\Models\Post_Job;
use App\Models\EmployerPlan;
use Illuminate\Http\Request;
use App\Models\PaymentHistory;
use Illuminate\Support\Facades\DB;
use App\Models\Qualifield_Employee;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Facade\FlareClient\Http\Response;
use MailchimpTransactional\ApiClient;
use Illuminate\Support\Facades\Storage;
use App\Helpers\Helper as HelpersHelper;
use App\Http\Resources\AccountSub;
use App\Http\Resources\AppliedEmployeeResource;
use App\Http\Resources\Employeeexit;
use App\Http\Resources\EmployeeHiredResource;
use App\Http\Resources\Post_JobFilterResource;
use App\Http\Resources\Post_jobResource;
use App\Http\Resources\Post_JobViewResource;
use App\Http\Resources\UserCollection;
use App\Http\Resources\UserResource;
use App\Models\AppliedJob;
use App\Models\Employee;
use App\Models\Adminreason;
use Illuminate\Support\Facades\Validator;
use phpDocumentor\Reflection\Types\Null_;
use Illuminate\Pagination\Paginator;
use Illuminate\Pagination\LengthAwarePaginator;
use App\Http\Resources\JobResource;
use App\Http\Resources\Paymenthis;
use App\Http\Resources\allPayHistory;
use App\Http\Resources\Post_jobimage;
use App\Http\Resources\Post_joblastest;
use App\Http\Resources\SearchEmployee;
use App\Models\Downloadplan;
use App\Models\EmployeeHired;
use App\Models\EmployerStatus;
use App\Models\subdownload;
use CloudinaryLabs\CloudinaryLaravel\Facades\Cloudinary ;
use Faker\Provider\ar_JO\Person;

// use PDF;
// use PhpOffice\Phpword\Settings;
class apiController extends Controller
{
    public function sign_up(Request $request){



        $person = User::where(['name'=>$request->name, 'email'=>$request->email, 'Role'=>$request->Role])->first();
        // return response()->json(empty($person->verification_code));
        //&&  $person->password??"" === NULL || $person &&  $person->password??"" === ''
        if(empty($person->password) && isset($person)){
          //sha1(time());
        //   $person->verification_code = sha1(time());
        //   $person->save();
           return response()->json(['exist'=>'an account assocaited with this email has being found in on rider institute do you want to continue']);
        }else if(!isset($person->password) && !isset($person)){
            $validator = Validator::make($request->all(),[
                "name" => 'required',
                "email" => 'required|email|unique:users',
                "Role"=>'required',
                'password'=>'required|confirmed|min:6',
               ]);

               if($validator->fails()){
                $errors = $validator->errors()->getMessages();
                return ['code'=>'1500', 'error'=>$errors];
               }

               $user =  new User();
               $user->name = $request->name;
               $user->email = $request->email;
               $user->Role = $request->Role;
               $user->verification_code = sha1(time());
               $user->password = Hash::make($request->password);
                $user->save();
               if($user){
                  $pay = new  Payment();
                  $pay->user_id = $user->id;
                  $pay->email =  $user->email;
                  $pay->subscription = '0';
                  $pay->verificationmessage = '';
                  $pay->referencecode = '';
                  $pay->save();

                  Controller::SendEmail($user->name, $user->email, $user->verification_code);


                                  return  response()->json(['success'=>'your accout has been created please check your email']);



               }

        }
         //stop here stephen
       }

       public function fillempty(Request $request){
        $user = User::where(['name'=>$request->name, 'email'=>$request->email, 'Role'=>$request->Role])->first();

        if($user){
                    $this->Setup($user->name, $user->verification_code, $user->email);
                        return  response()->json(['success'=>'your accout has been created please check your email']);
        }else{
            return  response()->json(['error'=>'this user does not exist']);
        }
      }


      public function correctpassword(Request $request){
         $user = User::where(['verification_code'=>$request->code])->first();
         if($user){
            $validator = Validator::make($request->all(),[
                'password'=>'required|confirmed|min:6',
               ]);

               if($validator->fails()){
                $errors = $validator->errors()->getMessages();
                return ['code'=>'1500', 'error'=>$errors];

               }
              $user->is_verified = 1;
               $user->password = Hash::make($request->password);
               $user->save();
               return response()->json(['success'=>'your password has been saved']);
         }elseif(!$user){
          return response()->json(['error'=>'this verification code does not exist']);
         }
      }


       public function login(Request $request){
         $validator = Validator::make($request->all(),[
             "email" => 'required|email',
             'password'=>'required|min:6',
            ]);

            if($validator->fails()){
             $errors = $validator->errors()->getMessages();
             return ['code'=>'1500', 'error'=>$errors];
            }

            $credentials = $request->only('email', 'password');

           if (Auth::attempt($credentials)){

             $user = User::where(['email'=>auth()->user()->email])->first();
              $token =  $user->createToken('my-app-token')->plainTextToken;

             if($user->is_verified == 0 && $user->suspensed == 0){
                 return ['error'=>'please go and verify your account'];
             }else if($user->is_verified == 1 && $user->suspensed == 0){
                 $response = [
                     'user'=>[
                      'id'=>$user->id,
                     'name'=>$user->name,
                     'email'=>$user->email,
                     'address'=>$user->Address,
                      'Role'=>$user->Role,
                      "suspensed"=>$user->suspensed,
                      'picture'=>$user->picture
                     ],
                      'token'=>$token
                 ];
                 return response($response, 201);
             }else if ($user->is_verified == 1 && $user->suspensed == 1){
               return response()->json(['error'=>'your account is inactive']);
             }

           }else{
             return ['error'=>'wrong password or email'];
           }
       }




       public function mail(Request $request){

          $user =   User::where(['verification_code'=>$request->verification_code])->first();

          if($user->is_verified != 1){
            $user->is_verified = 1;
            $user->save();
            return response()->json(['sent'=>'your account has been successfully verified']);

        }else if($user->is_verified == 1){

            return response()->json(['error'=>'this verification code has been used before']);
        }

       }

       public function check_emloyer($id){
           $user = User::find($id);
           if($user->Role === 'Employer'){
              if($user->Employer_exist){
                 return response()->json(['success'=>true]);
              }else{
                return response()->json(['virus'=>"please fill the form in employer profile page"]);
              }
           }else{
               return response()->json(['error'=>'Only for Employer']);
           }
       }

       public function insert_employer(Request $request){
                  $id = intval($request->id);
           $employee = Employer::where(['user_id'=>$id, 'Email'=>$request->email])->first();
           if(!$employee){
                $employer =  new  Employer();
                $employer->Company_Name = $request->company_name;
                 $employer->user_id =$id;
                 $employer->Industry = $request->Industries;
                 $employer->Number_of_employees = $request->employees;
                  $employer->Website = $request->Website;
                $employer->person_phone_number = $request->person_phone_number;
                 $employer->Email = $request->email;
                $employer->Telephone_Number = $request->Telephone;
                $employer->Address = $request->Address;
                $employer->save();
             return response()->json(['success'=>'your account has been successfully created']);
           }else{
               return response()->json(['error'=>'your profile has been created']);
           }
       }

       public function employer_info($id){
         $user = User::find($id);

          if($user->Role === 'Employer'){
              return response()->json(['success'=>$user->Employer_exist]);
          }else{
              return response()->json(['error'=>'your not an employer']);
          }

       }

       public function change_password(Request $request){
        $validator = Validator::make($request->all(),[
            "current_password" => 'required|alpha|min:8',
            "password"=>'required|alpha|confirmed|min:8',
           ]);

           if($validator->fails()){
            $errors = $validator->errors()->getMessages();
            return ['code'=>'1500', 'error'=>$errors];
           }
            //in the javascript code $request->email not be show in the html side
             $user = User::where('email', $request->email)->first();
           if(Hash::check($request->current_password, $user->password)){

              $user->password =  Hash::make(request('password'));
              $user->save();
              return response()->json(['sucess'=>'your password has been changed']);
           }else{
            return response()->json(['error'=>'please insert the correct password']);
           }


       }

       public function upload(Request $request){
             $user =  $this->getusers();
            // $user = User::where('id', $request->id)->first();
           if($user){
             $user->update(['picture'=>$request->file]);
            // $user->picture = $request->file;
            // $user->save();
               return response()->json(['success'=>'your has image  been successfully uploaded']);

           }else{
            return response()->json(['error'=>'your image have not been uploaded']);
           }
       }

       public function check_user_login($name){
          $user = User::where(['name'=>$name])->first()??"";
        //  $user = $this->getusers();
          $employer = Employer::where(['user_id'=>$user->id])->first()??"";
         if($user){
             $data = [
              'id'=>$user->id??"",
              'name'=>$user->name??"",
              'email'=>$user->email??"",
              'picture'=>$user->picture??"",
              'Role'=>$user->Role??"",
              "suspensed"=>$user->suspensed??"",
              'Address'=>$user->Address,
              'phone'=>$employer->Telephone_Number??"",
              'personal_phone'=>$employer->person_phone_number??"",
              'verified'=>$user->is_verified??""
             ];
          return response()->json(['success'=>$data]);
         }else{
             return response()->json(['error'=>'does not exist']);
         }
       }
              public function payment(Request $request){
                       $user = User::find($request->id);
                        $paid = $user->paid;
                        if($paid){
                            $paid->subscription  = intval($paid->subscription) + intval($request->Subscription);
                            $paid->referencecode =  $request->ReferenceCode;
                            $paid->verificationmessage = $request->message;
                           $itemSaved =  $paid->save();
                                if($itemSaved){
                                    // $paymentHistory = new PaymentHistory();
                                    // $paymentHistory->user_id  = $request->id;
                                    // $paymentHistory->email = $request->Email;
                                    // $paymentHistory->subscription = $request->Subscription;
                                    // $paymentHistory->verificationmessage = $request->message;
                                    // $paymentHistory->referencecode =  $request->ReferenceCode;
                                    // $paymentHistory->save();
                                    PaymentHistory::create([
                                        'user_id'  => $request->id,
                                        'email' => $request->Email,
                                        'subscription' => $request->Subscription,
                                        'verificationmessage' => $request->message,
                                        'referencecode' => $request->ReferenceCode
                                    ]);

                              return response()->json(['success'=>'your have successfully funded your wallet','amount'=>$paid->subscription]);
                             }
                        }else{
                            return response()->json(['error'=>'it is not successfully']);
                          }
              }

                          public function jobsdetail($id, $title){
                           $data = Post_Job::where(['id'=>$id, 'role'=>$title])->first();
                         ($data)? response()->json(['success'=>$data]):response()->json(['error'=>'please check the sent to your email']);
                          return $data;


                          }



                 public function jobs(Request $request){
                     $request->status;
                     if($request->status === 'Save Job'){
                        $post = new Post_Job();
                        //$request->companyname
                         $user = $this->getusers();
                         $employer = Employer::where(['user_id'=>$user->id])->first();
                        $post->companyname =$employer->Company_Name;
                        $post->jobSummary = $request->jobSummary;
                        $post->role = $request->role;
                        $post->salaryrange = $request->salaryrange;
                         $post->indraft = 1;
                        $post->changestatus = 1;
                        $post->location = $request->location;
                        $post->age_range = $request->age_range;
                        $post->email = $request->email;
                        $post->user_id = $request->id;
                        // $post->riders_location =  $request->RiderLocation;
                        $post->job_description = $request->Job_description;
                        $post->Qualification = $request->Qualification;
                        $post->ExperienceLength = $request->ExperienceLength;
                        $post->JobLevel = $request->JobLevel;
                        $post->SalaryCurrency = $request->SalaryCurrency;
                        $post->requirements = $request->requirements;
                        $post->save();


                              if($post){
                                return response()->json(['success'=>'your job requirement has been saved']);
                                }

                     }elseif($request->status === 'Proceed'){
                        $post = new Post_Job();
                        //$request->companyname
                         $user = $this->getusers();
                         $employer = Employer::where(['user_id'=>$user->id])->first();
                        $post->companyname = $employer->Company_Name;
                        $post->jobSummary = $request->jobSummary;
                        $post->role = $request->role;
                        $post->salaryrange = $request->salaryrange;
                        $post->location = $request->location;
                        $post->age_range = $request->age_range;
                        $post->email = $request->email;
                        $post->user_id = $request->id;
                        // $post->status = 'Awaiting Approval';
                         $post->indraft = 1;
                        $post->changestatus = 1;
                        // $post->riders_location =  $request->RiderLocation;
                        $post->job_description = $request->Job_description;
                        $post->Qualification = $request->Qualification;
                        $post->ExperienceLength = $request->ExperienceLength;
                        $post->JobLevel = $request->JobLevel;
                        $post->SalaryCurrency = $request->SalaryCurrency;
                        $post->requirements = $request->requirements;
                        $post->save();


                            if($post){
                            return response()->json(['success'=>'your job requirement has been saved', 'posted_id'=>$post->id]);
                            }


                     }

                 }

                 public function topjob(){
               // Rider::where(function($query) use($posted_job){
                 ///   //         $query->Where('role', 'LIKE', '%'.$posted_job->role.'%')
                 ///  $top =  Post_Job::whereIn(["subscriptionplan"=>['Advance','Enterprise'], 'status'=>['Active'] ])->take(12)->latest()->get();
                 $top = Post_Job::where(function($query){
                       $query->whereIn("subscriptionplan", ['Advance','Enterprise'])
                       ->where('statusofsub ', 'Active');
                 })->take(12)->latest()->get();
                   $all = Post_jobimage::collection($top);
                   return response()->json(['success'=>$all]);
                 }


                 public function lastestjob(){
                    $top =  Post_Job::where(['statusofsub'=>'Active'])->take(12)->latest()->get();
                      $all = Post_joblastest::collection($top);
                    return response()->json(['success'=>$all]);
                  }

        //  public function jobs(Request $request){
        //              // $request->SubscriptionPlan
        //                 $companyname = $request->companyname;
        //                 // $companypicture  =   $request->company_picture;

        //               $Eplan =  EmployerPlan::where(['nameofplan'=>$request->SubscriptionPlan])->first();
        //                $MonthlyPrice = intval($Eplan->pricepermonth);

        //                   $one = User::find($request->id);
        //                     $yourMoney = $one->paid;

        //                 $sub = intval($yourMoney->subscription);
        //                 if($sub >= $MonthlyPrice){


        //                    $answer =  $sub - $MonthlyPrice;
        //                    $Total = Payment::where(['email'=>$request->email])->first();
        //                    if($Total){
        //                         $Total->subscription = $answer;
        //                         $Total->save();
        //                         $post = new Post_Job();
        //                         $post->companyname = $request->companyname;
        //                         $post->jobSummary = $request->jobSummary;
        //                         $post->role = $request->role;
        //                         $post->salaryrange = $request->salaryrange;
        //                         $post->location = $request->location;
        //                         $post->age_range = $request->age_range;
        //                         $post->email = $request->email;
        //                         $post->user_id = $request->id;f
        //                         $post->subscriptionplan = $request->SubscriptionPlan;
        //                         $post->riders_location =  $request->RiderLocation;
        //                         $post->job_description = $request->Job_description;
        //                         $post->Qualification = $request->Qualification;
        //                         $post->ExperienceLength = $request->ExperienceLength;
        //                         $post->JobLevel = $request->JobLevel;
        //                         $post->SalaryCurrency = $request->SalaryCurrency;
        //                         $post->requirements = $request->requirements;
        //                         $post->save();



        //                                if($post){

        //                                     $messages =  Rider::where(function($query) use($request){
        //                                         $age =  explode("-", $request->age_range);
        //                                         // $Length = explode("-", $request->ExperienceLength);
        //                                          $query->Where('role', 'LIKE', '%'.$request->role.'%')
        //                                         //   ->orWhere('qualification', 'LIKE', '%'.$request->Qualification.'%')
        //                                            ->orWhere('state', 'LIKE', '%'.$request->location.'%')
        //                                         //   ->orWhere('experiencelength', 'LIKE', '%'.$request->ExperienceLength.'%')
        //                                           ->orWhere('joblevel', 'LIKE', '%'.$request->JobLevel.'%')
        //                                            ->whereBetween('age',[intval($age[0]), intval($age[1])] );
        //                                     })->get();


        //                                    $i = 0;
        //                                     $len = count($messages);
        //                                         foreach ($messages as $one){
        //                                                     // $Qualifield = new Qualifield_Employee();
        //                                                     // $Qualifield->user_id = $request->id;
        //                                                     // $Qualifield->posted_id = $post->id;
        //                                                     // $Qualifield->rider_id = $one->id;
        //                                                     // $Qualifield->save();

        //                                                     if ($i !== $len - 1) {
        //                                                         // sleep(1);
        //                                                          $message = [
        //                                                             "from_email" => "info@dellyman.com",
        //                                                             "subject" => "RidersInstitute",
        //                                                             "text" => "
        //                                                                           $one->name, We Have a Roles For You

        //                                                                             $companyname  Company in $post->location

        //                                                                             please on this link

        //                                                                             https://ridersinstitute.netlify.app/job/$post->id/$post->role

        //                                                                             to view the job

        //                                                                       ",
        //                                                             "to" => [
        //                                                                 [
        //                                                                     "email" =>$one->email,
        //                                                                     "type" => "to"
        //                                                                 ]
        //                                                             ]
        //                                                         ];

        //                                                         $mailchimp =new ApiClient();
        //                                                         //new MailchimpTransactional\ApiClient();
        //                                                         $mailchimp->setApiKey('L_npXuJr1AGIliqQjno6Jw');
        //                                                        // "reject_reason": null
        //                                                         $response = $mailchimp->messages->send(["message" => $message]);

        //                                                       //MailController::QualifiedEmployees($post->id, $post->role, $one->email, $one->name, $companyname,  $post->location);


        //                                                     } else if ($i == $len - 1) {
        //                                                         return response()->json(['success'=>'you have posted a job first']);
        //                                                     }
        //                                                     $i++;

        //                                                       }
        //                                    }

        //                             }

        //                       }else{

        //                        return response()->json(['error'=>'The money in your wallet is not enough']);

        //                         // $post = new Post_Job();
        //                         // $post->jobtitle = $request->jobtitle;
        //                         // $post->role = $request->role;
        //                         // $post->salaryrange = $request->salaryrange;
        //                         // $post->location = $request->RiderLocation;
        //                         // $post->age_range = $request->age_range;
        //                         // $post->email = $request->email;
        //                         // $post->user_id = $request->id;
        //                         // $post->in_draft = 1;
        //                         // $post->subscriptionplan = $request->SubscriptionPlan;
        //                         // $post->riders_location = $request->location;
        //                         // $post->job_description = $request->Job_description;

        //                         // $post->save();
        //                         // if($post){
        //                         //     return response()->json(['success'=>'you have posted a job second']);
        //                         // }
        //                 }
        //  }


               public function qulifield_rider($posted_id){
                     $user = Post_Job::find($posted_id);
                      $user? response()->json(['success'=>$user->ridersq]): response()->json(['error'=>'no data']);

               }

        public function edit_posted_job(Request $request){
       //$user = Post_Job::where(['id'=>$request->id])->first();
            $user = Post_Job::find($request->id);
            if ($user) {
                $user->companyname = $request->companyname;
                $user->role = $request->role;
                $user->salaryrange = $request->salaryrange;
                $user->jobSummary = $request->jobSummary;
                $user->location = $request->location;
                $user->email = $request->email;
                $user->age_range = $request->age_range;
                $user->riders_location = $request->location;
                $user->job_description = $request->Job_description;
                $user->Qualification = $request->Qualification;
                $user->ExperienceLength = $request->ExperienceLength;
                $user->JobLevel = $request->JobLevel;
                $user->SalaryCurrency = $request->SalaryCurrency;
                $user->requirements = $request->requirements;
                $user->save();
                return response()->json(['success'=>'you have successfully edited your posted job', 'posted_id'=>$user->id]);
            }

         }



          public function paystack_verify($ref){

                    $sercrtKey = "sk_test_8a40b954383a29bc20a711400387d2c3205478f9";
                    $curl = curl_init();

                    curl_setopt_array($curl, array(
                    CURLOPT_URL => "https://api.paystack.co/transaction/verify/$ref",
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_ENCODING => "",
                    CURLOPT_MAXREDIRS => 10,
                    CURLOPT_SSL_VERIFYHOST => 0,
                    CURLOPT_SSL_VERIFYPEER => 0,
                    CURLOPT_TIMEOUT => 30,
                    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                    CURLOPT_CUSTOMREQUEST => "GET",
                    CURLOPT_HTTPHEADER => array(
                        "Authorization: Bearer $sercrtKey",
                        "Cache-Control: no-cache",
                    ),
                    ));

                    $response = curl_exec($curl);
                    return $response;

                    $err = curl_error($curl);
                    curl_close($curl);

          }

        public function data_jobs($email, $id){
          $all =  Post_Job::where(['email'=>$email, 'user_id'=>$id])->get();
         return response()->json($all);
        }

        public function employerplan($data){
           $search = EmployerPlan::where(['nameofplan'=>$data])->first();
           return response()->json(['success'=>$search]);

        }


       public function searchpostedjob(Request  $request){
            //install "nicolaslopezj/searchable": "1.*"
            //to be able to do fulltext search
             $user =  $this->getusers();
          if($user->Role == "Employer"){
         if($request->has('search')){
           $data = Post_Job::search($request->get('search'))->where("position", "Active")->paginate(10);
                        return response()->json(["success"=>$data]);
         }else{
             $jobs = Post_Job::where(["position"=>"Active","user_id"=>$user->id])->get()->toArray();
             $page = 1;
                $answer = $this->paginate($jobs, 10, $page);
               return response()->json(["success"=>$answer]);
         } 
         
          }else{
            return response()->json(["error"=>"you are not an employer"]);
          }
           
       }


        public function resubscribe($id, $page){
            $user = User::find($id);
            $jobs = Post_Job::where("orderdraft", "!=", 1)->get();
          $steve = AccountSub::collection($jobs)->resolve();
          $answer = $this->paginate($steve, 10, $page);
          $answer->path();
          $answer->links();
         return response()->json($answer);
        //  return response()->json($steve);
        }


        // public function walletcal(Request $request){

        //  $user = User::where(['id'=>$request->id])->first();
        //  if($user->Role === 'Employer'){
        //     $planname = EmployerPlan::where(['nameofplan'=>$request->planname])->first();
        //     $person = User::find($request->id);
        //     $yourmoney = $person->paid;
        // $answeryourmoney =  intval($yourmoney->subscription);
        //  $answerplanname = intval($planname->pricepermonth);

        //  if($answeryourmoney  === 0){
        //     return response()->json(['error'=>'you do not have money in your wallet', 'money'=>$answerplanname]);
        //  }else if($answeryourmoney < $answerplanname){
        //   $solution =  $answeryourmoney -  $answerplanname;
        //   $number = strval($solution);
        //    $pay = Payment::where(['user_id'=>$request->id])->first();
        //    if($pay){
        //        $posted = new Post_Job();
        //        $posted->user_id = $request->id;
        //        $posted->subscriptionplan = $planname->nameofplan;
        //        $posted->save();
        //        $paymenthis = new PaymentHistory();
        //        $paymenthis->user_id = $request->id;
        //        $paymenthis->email = $user->email;
        //        $paymenthis->subscription = $number;
        //        $paymenthis->subscriptionname = $planname->nameofplan;
        //        $paymenthis->save();

        //        $pay->subscription = $number;
        //        $pay->save();
        //        $solve = explode('-', $number);
        //         $totalanswer = intval($solve[1]);


        //        return response()->json(['error'=>'you do not have money in your wallet', 'money'=>$solve[1]]);
        //    }
        //  }else if ($answeryourmoney < 0){


        //  }
        //  }else{
        //      return response()->json(['error'=>'you are not an employer']);
        //  }

        // }

         public function practiceSearch(Request $request){
           //***working code */
        //      $answer =  Post_Job::whereIn('role', $request->arr)->get();
        //   return response()->json($answer);
           //***working code */
         }
        public function selecte_jobposted($id){
            $data = Post_Job::find($id);
            return response()->json($data);

        }

        public function immdiatecharge(Request $request){
               $user = User::find($request->id);
            $unique_code =    HelpersHelper::Help(new Post_Job, 'user_id', 5, 'RI');
            if ($user->Role === 'Employer') {
                $planname = EmployerPlan::where(['nameofplan'=>$request->planname])->first();
                $person = User::find($request->id);
                $you =  $person->Employer_exist;
                $yourmoney = $person->paid;
                $answeryourmoney =  intval($yourmoney->subscription);
                $answerplanname = intval($planname->pricepermonth);

                if ($answeryourmoney  === 0) {
                    return response()->json(['error'=>'you do not have money in your wallet', 'money'=>$answerplanname, 'plan'=>$planname->nameofplan]);
                }else if($answeryourmoney < $answerplanname){
                      $solution =  $answeryourmoney -  $answerplanname;
                      $number = strval($solution);
                     $solve = explode('-', $number);
                     return response()->json(['error'=>'you do not have money in your wallet', 'money'=>$solve[1], 'plan'=>$planname->nameofplan]);
                }else if($answeryourmoney >= $answerplanname){

                              $pay = Payment::where(['user_id'=>$request->id])->first();
                              $user_company = Employer::where(['user_id'=>$request->id])->first();
                            //   $posted_job = Post_Job::where(['id'=>$request->posted_id])->first();
                              $posted_job =  Post_Job::find($request->posted_id);
                             if($pay &&  $posted_job && $posted_job->position == null){

                                $solution =  $answeryourmoney -  $answerplanname;
                                // return response()->json( $solution );

                                // $created_date = Carbon::now();
                                    //    $posted = new Post_Job();
                                    //    $posted->user_id = $request->id;
                                    //    $posted->subscriptionplan = $planname->nameofplan;
                                    //    $posted->save();
                                    /// HERE  THE CODE

                                    $arr = json_encode((object)[
                                      0=>array(
                                          "name"=>"New",
                                          "items"=>[]
                                      ),
                                      1=>array(
                                          "name"=>"Shortlisted",
                                          "items"=>[]
                                    ),
                                    2=>array(
                                      "name"=>"Invited",
                                      "items"=>[]
                                    ),
                                    3=>array(
                                      "name"=>"Unsuccessful",
                                      "items"=>[]
                                    ),
                                    4=>array(
                                      "name"=>"Interview",
                                      "items"=>[]
                                    ),
                                    5=>array(
                                        "name"=>"Successful",
                                        "items"=>[],
                                    ),
                                    6=>array(
                                      "name"=>"Hired",
                                      "items"=>[]
                                    ),
                                   ]);

                                    $shortarr = json_encode(array(
                                        array('id'=>0,'name'=>'New'),
                                        array('id'=>1,'name'=>'Shortlisted'),
                                        array('id'=>2, 'name'=>'Invited'),
                                        array('id'=>3, 'name'=>'Unsuccessful'),
                                        array('id'=>4, 'name'=>'Interview'),
                                        array('id'=>5, 'name'=>'Successful'),
                                        array('id'=>6, 'name'=>'Hired'),
                                    ));



                                        $word ='Awaiting Approval';
                                        $number = 0;
                                     $posted_job->subscriptionplan = $planname->nameofplan;
                                    //  $posted_job->expired_status = 0;
                                    //  $posted_job->approved_status = 0;
                                     $posted_job->job_code =  $unique_code;
                                    //  $posted_job->created_at =  $created_date;
                                   
                                    //  $posted_job->figure ="Awaiting Approval";
                                    //  $posted_job->changestatus=0;
                                       $posted_job->position =$word; 
                                    $posted_job->orderdraft=$number;
                                      $posted_job->download  = $planname->download;
                                      $posted_job->downloadcount =  $planname->number_of_download;
                                      $posted_job->save();
                                    //  $posted_job->update([
                                    //      'subscriptionplan' => $planname->nameofplan,
                                    //      'job_code' =>  $unique_code,
                                    //     "silence"=>0,
                                    //      "action"=>"Awaiting Approval",
                                    //      ]);
                                     

                                                         $Employestatus = new EmployerStatus();
                                                        $Employestatus->user_id = $posted_job->user_id;
                                                        $Employestatus->posted_id = $posted_job->id;
                                                        $Employestatus->longarray = $arr;
                                                        $Employestatus->shortarray = $shortarr;
                                                         $Employestatus->save();

                                       $paymenthis = new PaymentHistory();
                                       $paymenthis->user_id = $request->id;
                                       $paymenthis->email = $user->email;
                                       $paymenthis->subscription =  $answerplanname;
                                       $paymenthis->subscriptionname = $planname->nameofplan;
                                       $paymenthis->save();

                                       $pay->subscription = $solution;
                                       $pay->save();

                                    //    $messages =  Rider::where(function($query) use($posted_job){
                                    //           $age =  explode("-", $posted_job->age_range);
                                    //      // $Length = explode("-", $request->ExperienceLength);
                                    //         $query->Where('role', 'LIKE', '%'.$posted_job->role.'%')
                                    //       //   ->orWhere('qualification', 'LIKE', '%'.$request->Qualification.'%')
                                    //       ->orWhere('state', 'LIKE', '%'.$posted_job->location.'%')
                                    //      //   ->orWhere('experiencelength', 'LIKE', '%'.$request->ExperienceLength.'%')
                                    //       ->orWhere('joblevel', 'LIKE', '%'.$posted_job->JobLevel.'%')
                                    //           ->whereBetween('age',[intval($age[0]), intval($age[1])] );
                                    //                                         })->get();

//  $i = 0;
// $len = count($messages);
//  foreach ($messages as $one){
// if ($i !== $len - 1) {
//  $message_info = [
// "from_email"=>"info@dellyman.com",
// "subject"=>"RidersInstitute",
// "text" =>"$one->name, We Have a Roles For You
// $you->Company_Name in $posted_job->location
// please on this link
// https://ridersinstitute.netlify.app/job/$posted_job->id/$posted_job->role
// to view the job",
// "to" => [
//  [
// "email" =>$one->email,
// "type" => "to"
//  ]
// ]
// ];
// $mailchimp = new ApiClient();
// $mailchimp->setApiKey('L_npXuJr1AGIliqQjno6Jw');
// $response = $mailchimp->messages->send(["message" => $message_info]);
// }else if ($i == $len - 1) {
            return response()->json(['success'=>'your payment is successful', 'money'=>$solution]);
// }
// $i++;

// }
          
            }elseif($pay &&  $posted_job && $posted_job->position == 'Active'){
                // $createddate = $posted_job->updated_at->diffForHumans();
            //   $numberofdays = intval($planname->numberofemployee);

            //   $DBcurrentdate =  EmployerPlan::where(['nameofplan'=>$posted_job->subscriptionplan])->first();

            //   $DBnumberemployee = intval($DBcurrentdate->numberofemployee);
            //   $DBdateend = $posted_job->created_at->addDays($DBnumberemployee);

            $createddate = $posted_job->created_at;
            $end_date = Carbon::parse($posted_job->end_date);

              $numberofdays = intval($planname->numberofemployee);
             $diffdays = $createddate->diffInDays($end_date);
             $today = Carbon::now();

             if($diffdays > 0){
              $number = 0;
              $newdayadd = $end_date->addDay($numberofdays);
              $posted_job->subscriptionplan = $planname->nameofplan;
              $posted_job->end_date = $newdayadd;
              $posted_job->orderdraft=$number;
             $posted_job->download  = $planname->download;
             $posted_job->downloadcount =  $planname->number_of_download;
              $posted_job->save();
              $solution =  $answeryourmoney -  $answerplanname;
              $pay->subscription = $solution;
              $pay->save();
              return response()->json(['success'=>'your have successfully resubscribe', 'money'=>$solution]);
             }
             else if($diffdays === 0){
                  $word ='Expired';
                  $number = 0;
                // $newdayadd = $end_date->addDay($numberofdays);
                // $posted_job->subscriptionplan = $planname->nameofplan;
                // $posted_job->created_at = $today;
                // $posted_job->end_date = $newdayadd;
                //   $posted_job->statusofsub ="Expired";
                //  $posted_job->changestatus=0;
                $posted_job->position =$word;
                $posted_job->orderdraft=$number;
                $posted_job->save();
                // $solution =  $answeryourmoney -  $answerplanname;
                // $pay->subscription = $solution;
                // $pay->save();
                // return response()->json(['success'=>'you have successfully resubscribe', 'money'=>$solution]);
             }



            //   $newsub = Carbon::now();
            //  $diffHour = $DBdateend->diffInHours($newsub);
            //  $newnumberdays = intval($planname->numberofemployee);
            //    $subnew =  $newsub->addDays($newnumberdays);
            //   $newsubscription = $subnew->addHour($diffHour);
            //   $timecreated =  Carbon::createFromFormat('Y-m-d H:i:s', $newsubscription)->toDateTimeString();
            //  $answer = $DBdatefuture->diffInDays($subnew);

            //   $adding = $DBdatefuture->addDay($answer);

            //   $futuredate->diffInDays($futuredate);
            //    $posted_job->end_date =   $newsubscription;


            }else if($pay &&  $posted_job && $posted_job->position == 'Expired'){
              $createddate = $posted_job->created_at;
             // $end_date = Carbon::parse($posted_job->end_date);
             $today = Carbon::now();
              $planname->numberofemployee;
           //   return response()->json(['number'=>$planname->numberofemployee, 'today'=>$today, 'sub'=>$planname->nameofplan]);
                 $numberofdays = intval($planname->numberofemployee);
              //  $diffdays = $createddate->diffInDays($end_date);
                 $word ='Active';
                  $number = 0;

                    //Awaiting Approval
                $posted_job->created_at = $today;
                $newdayadd = $today->addDay($numberofdays);
                $posted_job->subscriptionplan = $planname->nameofplan;
                $posted_job->end_date = $newdayadd;
                $posted_job->position =$word;
                $posted_job->orderdraft=$number;
                $posted_job->save();
                $solution =  $answeryourmoney -  $answerplanname;
                $pay->subscription = $solution;
                $pay->save();
                return response()->json(['success'=>'you have successfully resubscribe', 'money'=>$solution]);


            }

                }
            }
            else{
                     return response()->json(['error'=>'you are not an employer']);
                 }
        }

        public function insertemployerplan(Request $request){

            $employer = new EmployerPlan();
            $employer->nameofplan = $request->plan;
            $employer->numberofemployee = $request->number;
            $employer->pricepermonth = $request->Month;
            $employer->save();

        }
        
        public function expiredpostedjob(){
          $user =  $this->getusers();
          $jobs =  $user->JobsPosting;
          $present = Carbon::now();
          foreach($jobs as $job){
                 $date_to_end = $job->end_date;
                $enddate =  Carbon::parse($date_to_end);
                $presenttime = Carbon::createFromFormat('Y-m-d H:i:s', $present );
                $timeend =  Carbon::createFromFormat('Y-m-d H:i:s', $enddate);
               $answer = $presenttime->gte($timeend);
               if($answer &&  $job->position   == 'Active' && $job->end_date !== NULL){
                $person = Post_Job::find($job->id);
                 $word ='Awaiting Approval';
                $person->update([
                    "position"=>$word
                ]);
               }else if($answer && $job->position != 'Active'  && $job->end_date == NULL){
                $person = Post_Job::find($job->id);
                $word = NULL;
                $person->update([
                    "position"=>$word,
                    "orderdraft"=>1
                ]);
               }
          }

        }


            public function postedjob($page){
            $user =  $this->getusers();
          if($user->Role == "Employer"){
            $jobs = Post_Job::where(["position"=>"Active","user_id"=>$user->id])->get()->toArray();
             $answer = $this->paginate($jobs, 10, $page);
            return response()->json(['success'=>$answer]);
          }else{
            return response()->json(['success'=>"your not an Employer"]);
          }

        }
        
     public function countalldownloads (){
          $user = $this->getusers();
          if($user->Role == "Employer"){
          $jobs =  Post_Job::where(["position"=>"Active", "download"=>1, "user_id"=>$user->id])->get();
        
         foreach($jobs as $job){
           $answer =  intval($job->downloadcount); 
            $arr = [];
            array_push($arr, $answer);
             $total =  array_sum($arr);
             return response()->json(["success"=>$total]);
          }

          }else{
            return response()->json(["error"=>"you are not an employers"]);
          }
        }
        
        
        
        public function postindate(User $user){
            // $users = User::find($id);
            $postedjobs = $user->rejob;

            foreach ($postedjobs as $postedjob) {
                  if( $postedjob->changestatus === 'Active' || $postedjob->changestatus === 'Awaiting Approval'){
                    $employeenum =  EmployerPlan::where(["nameofplan"=>$postedjob->subscriptionplan])->first();
                    $job = Post_Job::where(['id'=>$postedjob->id])->first();
                      $numofdaypersub = intval($employeenum->numberofemployee);
                      $end =  $job->created_at->addDays($numofdaypersub);
                    //   return response()->json($postedjob);
                      $job->end_date = $end;
                      $job->save();
                      //$timecreated =  Carbon::createFromFormat('Y-m-d H:i:s', $value->created_at)->toDateTimeString()
                  }
            }


        }
        
        public function postedjobAwaitingApproval(){
            $user =  $this->getusers();
            if($user->Role == "Employer"){
              $jobs = Post_Job::where(["position"=>"Awaiting Approval","user_id"=>$user->id])->get();
              return response()->json(['success'=>$jobs]);
            }else{
              return response()->json(['erroe'=>"your not an Employer"]);
            }
        }


        public function postedjobindaft(){
            $user =  $this->getusers();
            if($user->Role == "Employer"){
              $jobs = Post_Job::where(["orderdraft"=>1,"user_id"=>$user->id])->get();
              return response()->json(['success'=>$jobs]);
            }else{
              return response()->json(['error'=>"your not an Employer"]);
            }
        }


        public function updatephone(Request $request){
            $user = $this->getusers();
         $employer = Employer::where(["user_id"=>$user->id])->first();
          if($employer){
            $employer->update([
                "Telephone_Number"=>$request->office,
                "person_phone_number"=>$request->personal
            ]);
            //   $employer->Telephone_Number = $request->office;
            //   $employer->person_phone_number = $request->personal;
            //   $employer->save();
              return response()->json(['success'=>'you have succesfully updated your details']);
          }

        }

        public function changepassword(Request $request){
                          $validator = Validator::make($request->all(),[
                            "current_password" => 'required|min:8',
                            'password'=>'required|confirmed|min:8'
                           ]);

                           if($validator->fails()){
                            $errors = $validator->errors()->getMessages();
                            return ['code'=>'1500', 'error'=>$errors];
                           }

                            // $user = User::where(['email'=>$request->email])->first();
                             $user = $this->getusers();
                            if($user && Hash::check($request->current_password, $user->password)){
                                $user->update([
                                "password"=> Hash::make(request('password'))
                                ]);
                                //  $user->password =  ;
                                //  $user->save();
                                return response()->json(['sucess'=>'your password has been changed']);
                            }else{
                                return response()->json(['error'=>'please insert the correct password']);
                            }


        }

        public function walletaccount(){
            $user = $this->getusers();
        $pays =  PaymentHistory::where([['user_id', $user->id],  ['email', $user->email], ['verificationmessage', 'Verification successful']])->orderBy('id', 'desc')->get();
        $steve = Paymenthis::collection($pays);
         return response()->json($steve);
         }

        //  public function Testhelp(){
        //  $unique_code =    HelpersHelper::Help(new Post_Job, 'user_id', 5, 'RI');

        //    return response()->json($unique_code);

        //  }

         public function allpayment(){
            $user = $this->getusers();

            $pays =  PaymentHistory::where(['user_id'=>$user->id,  'email'=>$user->email, 'verificationmessage'=>NULL, 'referencecode'=>NULL])->latest()->orderBy('id', 'desc')->take(5)->get();
              $steve = allPayHistory::collection($pays);
            return response()->json($steve);

         }

        public function employerwallet(User  $user){
                 if( $user->Role === 'Employer'){
                    return response()->json(['success'=>$user->paid]);
                      }else{
                        return response()->json(['Error'=>'your not an employer']);
                      }
        }


    //   public function numberofemployeeapplied($id, $page){
    //          $user =  User::find($id);
    //        $alljob =  $user->JobsPosting;
    //        $steve = [];
    //       foreach ($alljob as $job) {
    //      $Applied =  AppliedJob::where(["postedjob_id"=>$job->id])->get()->toArray();
    //       $num = count($Applied);

    //      // $approved =  Carbon::createFromFormat('Y-m-d H:i:s', $job->created_at)->toDateTimeString();
    //       $approved = Carbon::parse($job->created_at)->format('d/m/Y');
    //       $end =  Carbon::parse($job->end_date)->format('d/m/Y');
    //       $created =  Carbon::parse($job->updated_at)->format('d/m/Y');
    //        $obj = array('id'=>$job->id, 'role'=>$job->role, 'approved_date'=> $created,  'end_date'=>$end, "created_date"=>$approved, "number_of_candidate"=>$num);
    //        array_push($steve, $obj);
    //       }
    //        $answer = $this->paginate($steve, 10, $page);
    //        $answer->path();
    //        $answer->links();
    //       return response()->json($answer);
    //          //JobsPosting
    //   }





  
public function numberappliant($page){
      //resolve() it convert resources into an array
$person = $this->getusers();
 $Jobs = Post_Job::where(["position"=>"Active", "user_id"=>$person->id])->get();
    $data = Post_jobResource::collection($Jobs)->resolve();
    $more = $this->paginate($data, 10, $page);
   return response()->json(['success'=>$more]);
  }

  public function postjobs ($id){
     $post = Post_Job::find($id);
    //  return $post->AppliedEmployee;
    $answer = new Post_JobFilterResource($post);
    $show =  EmployerStatus::where(['posted_id'=>$id])->first();
    return response()->json(['success'=>$answer, 'other'=>$show->longarray, 'shortarray'=>$show->shortarray]);
  }

  public function updateapplied(Request $request){
    $applied =  AppliedJob::find($request->id);
    $post = Post_Job::find($request->postdid);
    $hiredemployee = EmployeeHired::where(["employee_id"=>$applied->user_id, "employer_id"=>$post->user_id])->first();
    if($request->status === 'Hired'){
        $hired = new EmployeeHired();
        $applied->update([
         'status'=>$request->status
        ]);
        // $applied->status = $request->status;
        // $applied->save();
        $date = Carbon::now();
        $hired->employee_id = $applied->user_id;
        $hired->employer_id = $post->user_id;
        $hired->posted_id = $post->id;
        $hired->date_started = $date;
        $hired->status = 'Hired';
        $hired->save();
         $answer = new Post_JobFilterResource($post);
         $show =  EmployerStatus::where(['user_id'=>$post->user_id])->first();
        return response()->json(['success'=>$answer, 'other'=>$show->longarray]);
    }else if($request->status !== 'Hired'){
        $applied->update([
            'status'=>$request->status
           ]);
           $answer = new Post_JobFilterResource($post);
           $show =  EmployerStatus::where(['user_id'=>$post->user_id])->first();
          return response()->json(['success'=>$answer, 'other'=>$show->longarray]);
    }

  }

  public function newtest(Request $request){
    // $uploadedFileUrl = Cloudinary::uploadFile($request->file('file')->getRealPath())->getSecurePath();
    // return $uploadedFileUrl;
    // $domPdfPath = base_path('vendor/dompdf/dompdf');
    //$pdf = PDF::loadview('pdf_view',$request->file('file'));
   // return $pdf->output();
      $name = $request->file('file')->getClientOriginalName();
      $path = $request->file('file');
    if (strpos($name, 'docx') !== false) {
       // $color = explode(".", $name);
        // $uploadedFileUrl = Cloudinary::uploadFile($request->file('file')->getRealPath(),[
        //     "public_id"=>$color[0].'.docx',
        //     "resource_type"=>'image',
        //     "raw_convert" => "aspose",
        //     "use_filename" => TRUE,
        //   "unique_filename" => FALSE,
        //     "pages" => TRUE,
        //     "eager" => [
        //         ["fetch_format" => "auto", "flags" => "attachment:".$color[0], "format" => "Pdf"]
        //         ]
        // ]);

        $clouddata = $this->cloud($path);

        // $clouddata->getSecurePath();
        // $clouddata->getPublicId();
        return response()->json(['publicid'=>$clouddata->getPublicId(), 'url'=>$clouddata->getSecurePath()]);
    } elseif (strpos($name, 'pdf') !== false) {
        // $color = explode(".", $name);
        // $uploadedFileUrl = Cloudinary::uploadFile($request->file('file')->getRealPath(),[
        //     "public_id"=>$color[0].'.pdf',
        //     "pages" => TRUE,
        //      "resource_type"=>'image',
        //      "eager" => [
        //          ["fetch_format" => "auto", "flags" => "attachment:".$color[0], "format" => "Pdf"]
        //          ]
        //     // "raw_convert" => "aspose"
        // ]);
        $clouddata = $this->cloud($path);

        $clouddata->getSecurePath();
        $clouddata->getPublicId();

        return response()->json(['publicid'=>$clouddata->getPublicId(), 'url'=>$clouddata->getSecurePath()]);
    }

        }


        public function insertemployerstatus(Request $request){
          $status =  EmployerStatus::where(['user_id'=>$request->user_id, 'posted_id'=>$request->posted_id])->first();

          // if(!$status){
          //     $Employestatus = new EmployerStatus();
          //     $Employestatus->user_id = $request->user_id;
          //     $Employestatus->posted_id = $request->posted_id;
          //     $Employestatus->longarray = $request->longarray;
          //     $Employestatus->shortarray = $request->shortarray;
          //    $saveall = $Employestatus->save();
          //     if($saveall){
          //       $show =  EmployerStatus::where(['user_id'=>$request->user_id])->first();
          //       return response()->json($show);
          //     }
          // }else
          if($status){


        //  $arr = json_encode((object)[
        //         0=>array(
        //              "name"=>"New",
        //              "items"=>[]
        //         ),
        //         1=>array(
        //             "name"=>"Shortlisted",
        //             "items"=>[]
        //        ),
        //        2=>array(
        //         "name"=>"Invited",
        //         "items"=>[]
        //        ),
        //        3=>array(
        //         "name"=>"Unsuccessful",
        //         "items"=>[]
        //        ),
        //        4=>array(
        //         "name"=>"Interview",
        //         "items"=>[]
        //        ),
        //        5=>array(
        //            "name"=>"Successful",
        //            "items"=>[],
        //        ),
        //        6=>array(
        //         "name"=>"hire",
        //         "items"=>[]
        //        ),

        //  ]);

        //    $shortarr = array(
        //        array('id'=>0,'name'=>'New'),
        //        array('id'=>1,'name'=>'Shortlisted'),
        //        array('id'=>2, 'name'=>'Invited'),
        //        array('id'=>3, 'name'=>'Unsuccessful'),
        //        array('id'=>4, 'name'=>'Interview'),
        //        array('id'=>5, 'name'=>'Successful'),
        //        array('id'=>6, 'name'=>'hire'),
        //    );
              $status->user_id = $request->user_id;
              $status->posted_id = $request->posted_id;
              $status->longarray = $request->longarray;
              $status->shortarray = $request->shortarray;
             $saveall = $status->save();
            if($saveall){
              $show =  EmployerStatus::where(['user_id'=>$request->user_id])->first();
              return response()->json($show);
            }
          }
        }

        public function allemployeestatus($user_id, $posted_id){
            $status =  EmployerStatus::where(['user_id'=>$user_id, 'posted_id'=>$posted_id])->first();
            return response()->json($status);
        }



        public function addemployee(Request $request){
            // return  response()->json($request->all());

            $user = User::where(['email'=>$request->email])->first();

              $employee = Employee::where(['email'=>$request->email])->first();

           if($user && $employee){
            return response()->json(['error'=>"sorry this  already exist"]);
           }else if($user && !$employee){
            return response()->json(['error'=>"sorry this  already exist"]);
           }
           else if(!$user && !$employee){
            $person = new User();
            $person->name = $request->name;
            $person->Role = 'Employee';
            $person->is_verified = 0;
            $person->verification_code = sha1(time());
            $person->email = $request->email;
            $person->save();
            if($person){
              $employees = new Employee();
              $employees->name = $request->name;
              $employees->email = $person->email;
              $employees->date_of_birth =  $request->dateofbirth;
              $employees->lga  =  $request->city;
              $employees->state = $request->state;
              $employees->gender = $request->gender;
              $employees->age = $request->age;
              $employees->user_id = $person->id;
              $employees->role = $request->role;
              $employees->highest_degree = $request->qualification;
              $employees->experience = $request->experience;
              $employees->phone_number = $request->phone_number;
              $employees->save();
              $hired = new EmployeeHired();
              $hired->employee_id = $person->id;
              $hired->employer_id = $request->employer_id;
              $hired->status = 'Hired';
              $hired->save();
              $Appliedjobs = new AppliedJob();
              $Appliedjobs->name = $request->name;
              $Appliedjobs->user_id = $person->id;
              $Appliedjobs->phone_number = $request->phone_number;
              $Appliedjobs->employer_id = $request->employer_id;
              $Appliedjobs->experiencelenght = $request->experience;
              $Appliedjobs->public_id = 0;
              $Appliedjobs->qualification = $request->qualification;
              $Appliedjobs->appliant_cv = 'nothing';
              $Appliedjobs->status =  'Hired';
              $Appliedjobs->save();
              return response()->json(['success'=>'you have sucessfully add an employee']);
            }
           }
        }
        public function usertest(Request $request){
          $user =  User::where(['name'=>$request->name, 'email'=>$request->email ])->first();

          if($user){
            return $user;
          }else{
             return $user;
          }
        }

        public function changestatus(Request $request){
           $data = json_decode($request->data);
                $i=0;
          $len = count($data);
          foreach ($data as $value) {
                // if ($i !== $len - 1) {
                $applied =  AppliedJob::find($value->id);
                $applied->status=$value->status;
                $applied->save();
               /// return response()->json(['success'=>'it has been successfully change']);
                // }else if ($i == $len - 1) {
                // }
                // $i++;
            }
            return response()->json(['success'=>'it has been successfully change']);
        }

            public function employerworker(){
              $user = $this->getusers();
              if($user->Role === "Employer"){
               return EmployeeHiredResource::collection($user->hiredemployee);
              }else{
                  return response()->json(["error"=>"your not an employer"]);
              }
            }

        // public static function lois($user){
        //    return  $user->rejob;
        //    $str = "codility we test coder";
        //    $code = $str.explode(" ", $str);
        //    for($i=0; i < count($code); i++){
        //         $code[]
        //    }
        // }

        public function downloadall(){
            $user = $this->getusers();
              if ($user->Role == "Employer") {
                  $data = Downloadplan::orderBy('id', 'asc')->get();
                  return response()->json(['success'=>$data]);
              }else{
                return response()->json(['error'=>'you are not an employer']);
               }
          }

          public function getallEmployerplans (){
            $user = $this->getusers();
            if ($user->Role === "Employer") {
                $employerplan = EmployerPlan::orderBy('id', 'asc')->get();
                return response()->json(['success'=>$employerplan]);
            }
        }


          public function downloadcalculation(Request $request){
             $user = $this->getusers();
                 if ($user->Role == "Employer") {
                  $payment =  Payment::where(['user_id'=>$user->id])->first();
                   $youramout = intval($payment->subscription);
                   $request->amount;
                      $down = Downloadplan::find($request->download_id);
                   if($request->amount > $youramout){
                     $solution = $request->amount - $youramout;
                      return response()->json(['owe'=>'fund you wallet', 'money'=>$solution]);
                   }else if($request->amount <= $youramout){
                       $solution = $youramout - $request->amount;
                    //    'subname',
                    //    'number_of_download',
                    //    'user_id',
                    //    'amount'
                       $payment->update([
                         "subscription"=>$solution,
                       ]);

                       PaymentHistory::create([
                           'user_id' => $user->id,
                           'email' => $user->email,
                           'subscription' =>$request->amount,
                            'subscriptionname' => $down->nameofplan
                       ]);

                       $sub  =   subdownload::where(['user_id'=>$user->id])->first();
                       if(!$sub){
                           subdownload::create([
                             'subname'=>$down->nameofplan,
                             'numberofdownload'=>$down->numberofdownload,
                             'user_id'=>$user->id,
                             'amount'=>$down->amount,
                             'email'=>$request->email

                           ]);
                       }else{
                           $answer = $down->number_of_download + $sub->numberofdownload;
                        $sub->update([
                         'subname'=>$down->nameofplan,
                         'numberofdownload'=>$answer,
                         'amount'=>$down->amount,
                        ]);
                       }


                       return response()->json(['success'=>'you have paid payment successful', 'money'=>$solution]);
                   }

            }else{
                return response()->json(['error'=>'you are not an employer']);
               }

          }

          public function subscriptiondownload(){
              $user = $this->getusers();
              if ($user->Role == "Employer") {
                $subscription = subdownload::where(['user_id'=>$user->id])->first();
                return response()->json(['success'=>$subscription]);
              }else{
               return response()->json(['error'=>'your are not an employer']);
              }
          }

  public function updatesubdownload(Request $request){
          $user = $this->getusers();
          if($user->Role == "Employer"){
              //"downloadcount", '>', 0
          $sub = Post_Job::where('user_id',$user->id)->where('position', 'Active')->where("downloadcount", '>', 0)->first();
          if($sub){
            $answer = intval($sub->downloadcount)  - intval($request->figure);
            //return $answer;
            $sub->downloadcount = $answer;
             $sub->save();
            $jobs =  Post_Job::where(["position"=>"Active", "download"=>1, "user_id"=>$user->id])->get();
            foreach($jobs as $job){
              $answer =  intval($job->downloadcount); 
               $arr = [];
               array_push($arr, $answer);
                $total =  array_sum($arr);
                return response()->json(["success"=>$total]);
             }
          }else{
            return response()->json(["error"=>"you have zero download"]);
          }
          }else{
            return response()->json(['error'=>'your are not an employer']);
          }
      }

          public function paymentdownload(Request $request){
              $user = $this->getusers();
            $paid =  Payment::where(['user_id'=>$user->id])->first();
            if($paid){
                $paid->subscription  = intval($paid->subscription) + intval($request->Subscription);
                $paid->referencecode =  $request->ReferenceCode;
                $paid->verificationmessage = $request->message;
               $itemSaved =  $paid->save();
                    if($itemSaved){
                        // $paymentHistory = new PaymentHistory();
                        // $paymentHistory->user_id  = $request->id;
                        // $paymentHistory->email = $request->Email;
                        // $paymentHistory->subscription = $request->Subscription;
                        // $paymentHistory->verificationmessage = $request->message;
                        // $paymentHistory->referencecode =  $request->ReferenceCode;
                        // $paymentHistory->save();
                        // formData.append('email', email)
                        // formData.append('Subscription', ansamout)
                        // formData.append('message', res.data.message)
                        // formData.append('ReferenceCode', ref)
                        // formData.append('subscriptionname', nameofplan)
                        PaymentHistory::create([
                            'user_id'=>$user->id,
                            'email'=>$request->email,
                            'subscription'=>$request->Subscription,
                            'verificationmessage' => $request->message,
                            'referencecode' => $request->ReferenceCode,
                        ]);

                  return response()->json(['success'=>'your have successfully paid','amount'=>$paid->subscription]);
                 }
            }else{
                return response()->json(['error'=>'it is not successfully']);
              }

          }


         public function termination(Request $request){
            $user =  $this->getusers();
         //  $user = User::find($request->userid);

           if ($user->Role == "Employer") {
               $apply = AppliedJob::find($request->id);
               //return $apply;
               if ($apply && $apply->status == "Hired") {

                   $postid = intval($request->postid);
                   $post = Post_Job::find($postid);

                   $employeehired = EmployeeHired::where(["employee_id"=>$request->employee_id, "employer_id"=>$user->id])->first();
                             // $employeehired->employer_id = $post->user_id;
                    // $employeehired->employee_id = $request->employee_id;
                    // $employeehired->posted_id =  $postid;
                    // $employeehired->status = $request->reason;
                    // $employeehired->reason_by_employer =  $request->reason;
                    // $employeehired->explaination = $request->explaination;
                    // $employeehired->end_data = $request->decisiondate;
                    // $employeehired->recommend_candiate = $request->recandidate;
                    // $employeehired->employe_candiate_again = $request->rehire;
                    // $apply->status = $request->reason;
                    // $apply->save();
                    // $employeehired->save();
                   if ($employeehired) {
                       $employeehired->update([
                        'employer_id'=> $user->id,
                        'employee_id' => $request->employee_id,
                        'posted_id' =>  $postid?$postid:NULL,
                        'status' => $request->reason,
                        'reason_by_employer' =>  $request->reason,
                        'explaination' => $request->explaination,
                        'end_data' => $request->decisiondate,
                        'recommend_candiate' => $request->recandidate,
                        'employe_candiate_again' => $request->rehire,
                       ]);
                       $apply->update([
                        'status' => $request->reason
                       ]);
                    $answer =  EmployeeHiredResource::collection($user->hiredemployee);
                    return response()->json(["success"=>"the applicant status has been updated", "array"=>$answer]);
                }else{
                    return response()->json(["error"=>"this person does not exist"]);
                }
               }
           }else{
               return response()->json(["error"=>"you not an employer"]);
           }
         }

        public function employeemoreinfo($employer_id, $employee_id){
            $user = User::find($employer_id);
            if($user->Role == "Employer"){
               $employee = User::find($employee_id);
               $employee->employeehired;
               $singleemployee = Employeeexit::collection($employee->employeehired);
               return response()->json(["success"=>$singleemployee]);
            }else{
                return response()->json(['error'=>"you are not an employer"]);
            }
        }

        public function employerexitreason(){
          $user = $this->getusers();
          if($user->Role == "Employer"){
          $reason =  Adminreason::all();
          return response()->json(['success'=>$reason]);
          }else{
            return response()->json(['error'=>"you are not an employer"]);

          }

        }

        public function searchemployeedata(Request $request){

            // $validator = Validator::make($request->all(),[
            //     "age" => 'required|alpha_dash',
            //     "role" => 'required|regex:/^[a-zA-Z ]*$/',
            //     "gender"=>'required|regex:/^[a-zA-Z ]*$/',
            //     'state'=>'required|regex:/^[a-zA-Z ]*$/',
            //     "experience" =>"required|alpha_dash",
            //     "lga"=>'required|regex:/^[a-zA-Z- ]*$/',
            //     'Degree'=>'required',
            //    ]);

            //    if($validator->fails()){
            //     $errors = $validator->errors()->getMessages();
            //     return ['code'=>'1500', 'error'=>$errors];
            //    }
             $ans =  $request->age == ''?'-':$request->age;
                 $age = explode("-", $ans);
 $messages = Employee::where(function($query) use($request){
    $query->Where('role', 'like', '%' . $request->role . '%')
    ->Where('gender', 'like', '%' .$request->gender. '%')
     ->Where('state', 'like', '%' . $request->state. '%');
    //->Where('highest_degree', 'like', '%' . $request->Degree. '%');

    //   ->Where('lga','like', '%' . $request->lga. '%');
 })->get();


//  ->where(function($query) use($request){
//     $query->Where('highest_degree', 'like', '%' . $request->Degree. '%');
//  })->where(function($query) use($request){
//     $query->Where('experience_length', 'like', '%' . $request->experience. '%');
//  })->where(function($query) use($request){
//     $query->Where('lga','like', '%' . $request->lga. '%');
//  })->where(function($query) use($age){
//     $query->Where('age',[intval($age[0]), intval($age[1])]);
//  })

 $messagetwo = Employee::where(function($query) use($request, $age){
    $query->Where('experience_length', 'like', '%' . $request->experience. '%')
    ->Where('highest_degree', 'like', '%' . $request->Degree. '%')
     ->whereBetween('age',[intval($age[0]), intval($age[1])]);
   //   ->Where('lga','like', '%' . $request->lga. '%');
})->get();

 //$result = array_merge($messages, $messagetwo);

$search = SearchEmployee::collection($messages, $messagetwo);
return response()->json(['success'=>$search]);
//  where(function($query) use($request){
//     $query->Where('gender', 'like','%'. $request->gender.'%');
//  })->where(function($query) use($request){
//     $query->Where('state', 'like','%'. $request->state.'%');
//  })->where(function($query) use($request){
//     $query->Where('highest_degree', $request->Degree);
//  })->where(function($query) use($request){
//     $query->Where('experience_length', $request->experience);
//  })->where(function($query) use($request){
//     $query->Where('lga', $request->lga);
//  })->where(function($query) use($age){
//     $query->Where('age',[intval($age[0]), intval($age[1])]);
//  })->get();
//  where("role", 'like', '%'.$request->role.'%')
//  ->orWhere('gender','like', '%'.$request->gender.'%')
//  ->orWhere('state','like', '%'.$request->state.'%')
//  ->orWhere('experience_length','like', '%'. $request->experience.'%')
//  ->whereBetween('age',[intval($age[0]), intval($age[1])])->get();
                        //  $messages =  Employee::where(function($query) use($request){
                        //     $ans =  $request->age == ''?'-':$request->age;
                        //     $age = explode("-", $ans);
                        //        $query->WhereRaw('role', 'LIKE', '%'.$request->role.'%');
                        //        //  $query->WhereRaw('role', 'LIKE', "%$request->role%");
                        //         //  ->orWhereRaw('gender', 'LIKE', "%{$request->gender}%")
                        //         //   ->orWhereRaw('state', 'LIKE', "%{$request->state}%")
                        //         //    ->orWhereRaw('experience_length', 'LIKE', "%{$request->experience}%")
                        //         //    ->orWhereRaw('lga', 'LIKE', "%{$request->lga}%")
                        //         // ->orWhereRaw('highest_degree', 'LIKE', "%{$request->Degree}%")
                        //         //     ->whereBetween('age',[intval($age[0]), intval($age[1])] );
                        //                  })->get();

                                //  $Search = SearchEmployee::collection($messages);
                                // return response()->json(['success'=>$Search]);
                    //    $user = $this->getusers();
                    //     if($user->Role === 'Employer'){
                    //         $messages = Employee::orderBy('id', 'DESC')->get();
                    //         $Search = SearchEmployee::collection($messages);
                    //        return response()->json(['success'=>$Search]);
                    //     }else{
                    //         return response()->json(['error'=>'you are not an employer']);
                    //     }



        }

        public function displayplans(){
            $plans = EmployerPlan::orderBy("id","ASC")->get();
            return response()->json(['success'=>$plans]);
        }

       public function forgetpassword (Request $request){
        $validator = Validator::make($request->all(),[
          "email"=>'required|email',
         ]);

         if($validator->fails()){
          $errors = $validator->errors()->getMessages();
          return ['code'=>'1500', 'error'=>$errors];
         }
        $user = User::where(['email'=>$request->email])->first();
        if($user){
            $user->update([
               'verification_code'=>sha1(time())
            ]);
            $person = User::where(['email'=>$request->email])->first();
            $this->Setup($person->name, $person->verification_code, $person->email);
            return  response()->json(['success'=>'please check your email']);

        }
       }
       public function logout(){
         auth()->user()->tokens()->delete();
         return response()->json(['success'=>'logged out']);
       }
   
    public function paginate($items, $perPage = 4, $page = null){
    $page = $page ?: (Paginator::resolveCurrentPage() ?: 1);
    $total = count($items);
    $currentpage = $page;
    $offset = ($currentpage * $perPage) - $perPage ;
    $itemstoshow = array_slice($items , $offset , $perPage);
    return new LengthAwarePaginator($itemstoshow ,$total ,$perPage);
} 
   
       
}
