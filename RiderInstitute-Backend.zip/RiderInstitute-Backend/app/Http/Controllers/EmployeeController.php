<?php

namespace App\Http\Controllers;

use App\Http\Resources\AppliedEmployee;
use App\Http\Resources\AppliedEmployeeJob;
use App\Http\Resources\EmployeeAvailiableJob;
use App\Http\Resources\Employeejobs;
use App\Http\Resources\EmployeeAvailible;
use App\Http\Resources\UserEmployee;
use App\Models\AppliedJob;
use App\Models\Employee;
use App\Models\Employer;
use App\Models\EmployerStatus;
use App\Models\Payment;
use App\Models\Post_Job;
use App\Models\ridersinstituteresume;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Pagination\Paginator;
use Illuminate\Pagination\LengthAwarePaginator;
// use Cloudinary\Cloudinary;
use CloudinaryLabs\CloudinaryLaravel\Facades\Cloudinary ;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class EmployeeController extends Controller
{

  public function insertemployeedata(Request $request){
   // $user = User::where(['id'=>$request->id, 'email'=>$request->email])->first();
    $user =  $this->getusers();
    if($user->Role === "Employee"){
        $validator = Validator::make($request->all(),[
            "resume" => 'required|mimes:pdf,docx,doc',
            'phone_number' =>'required',
            'date_of_birth' =>'required',
            'state' =>'required',
            'lga' =>'required',
            'experience_length' =>'required',
            'gender' =>'required',
            'age' =>'required',
            'role' =>'required',
            'highest_degree' =>'required',
            'skills' =>'required',
            'experience' =>'required'
           ]);

           if($validator->fails()){
            $errors = $validator->errors()->getMessages();
            return ['code'=>'1500', 'error'=>$errors];
           }

      $employee =  Employee::where(['user_id'=>$user->id, 'email'=>$user->email])->first();
      if(!$employee){
      $path = $request->resume;
      $totalPages = $this->countPages($path);
        $clouddata = $this->cloud($path);
     $url = $clouddata->getSecurePath();
     $publicId = $clouddata->getPublicId();
         Employee::create([
            'name' => $user->name,
            'phone_number' => $request->phone_number,
            'email' => $user->email,
            'date_of_birth' => $request->date_of_birth,
            'state' => $request->state,
            'lga' => $request->lga,
            'user_id' => $user->id,
            'experience_length' => $request->experience_length,
            'gender' => $request->gender,
            'age' => $request->age,
            'role' => $request->role,
            'highest_degree' => $request->highest_degree,
            'skills' => $request->skills,
            'experience' => $request->experience
         ]);
         ridersinstituteresume::create([
          'employee_id' => $user->id,
          'resumelink' => $url,
           'numberofpages' => $totalPages,
            'publicId' => $publicId
         ]);
        //  $employees->save();
         return response()->json(['success'=>'you have updated your profile']);

      }else{

        return response()->json(['error'=>'you have inserted data before']);
      }

    }else{
        return response()->json(['error'=>'you are not an employee']);
    }

  }


    public function employeedata($id, $email){
        $person = $this->getusers();
      $employee =  Employee::where(['user_id'=>$person->id, 'email'=>$person->email])->first();

      $data = [];

      if($employee){
         // $user = User::where(['id'=>$employee->user_id])->first();
          $user = $this->getusers();

    //    $birth = Carbon::createFromFormat('Y-m-d H:i:s', $employee->date_of_birth)->toDateTimeString();
    //    $dateofbirth= Carbon::parse($employee->date_of_birth);
            //  $birth =  date("d/m/Y", strtotime($employee->date_of_birth));
        $obj =  array('name'=>$user->name, "phone"=>$employee->phone_number, "email"=>$employee->email, "dateofbirth"=>$employee->date_of_birth, "state"=>$employee->state, "local"=>$employee->lga, "experiencelength"=>$employee->experience_length, "gender"=>$employee->gender, "role"=>$employee->role, "degree"=>$employee->highest_degree, "Skill"=>$employee->skills, "experience"=>$employee->experience, "age"=>$employee->age);
        array_push($data, $obj);
          return response()->json(['success'=>$data]);
      }else{
        return response()->json(['error'=>'you have no data']);
      }

    }


    public function availablejobs($page){
        $user = $this->getusers();
       if($user->Role === 'Employee'){
          $jobs = Post_Job::where(["statusofsub"=>"Active"])->get();
         $arr = EmployeeAvailible::collection($jobs)->resolve();
          $more = $this->paginate($arr, 10, $page);
         return response()->json(['data'=>$more]);


       }else{
          return response()->json(['error'=>'your not an employee']);
       }

    }


     public function testavailablejobs(){
        $user = $this->getusers();
       if($user->Role === 'Employee'){
          $jobs = Post_Job::orderBy('id', 'DESC')->get();
          $present = Carbon::now();
        foreach ($jobs as $job) {
              $end = $job->end_date;
             $enddate =  Carbon::parse($end);
             $presenttime = Carbon::createFromFormat('Y-m-d H:i:s', $present );
             $timeend =  Carbon::createFromFormat('Y-m-d H:i:s', $enddate);
            $time = $presenttime->gte($timeend);
            if( $job->status === 'Active' && $time && $job->end_date !== null){
            $presentjob = Post_Job::find((int)$job->id);
            $presentjob->update([
              "status"=>"Expired",
            ]);
            $data = EmployeeAvailiableJob::collection($jobs);
            return response()->json(['data'=>$data, 'show'=>'first']);
            }else if( $job->status === 'Active' && !$time && $job->end_date !== null){
                $posted = Post_Job::where(['status'=>'Active'])->orderBy('id', 'DESC')->get();
                $data = EmployeeAvailiableJob::collection($posted);
                return response()->json(['data'=>$data, 'show'=>'second']);
            }
        }
       }else{
          return response()->json(['error'=>'your not an employee']);
       }
    }

    public function findjob($id){
       $job = Post_Job::where(['id'=>$id])->first();
       $arr = [];
       if($job){
        $user = User::where(['id'=>$job->user_id])->first();
        $user->picture;
         $employer =  Employer::where(['user_id'=>$job->user_id])->first();
         $employer->Address;
         $employer->Company_Name;
         $employer->Industry;
         $employer->Telephone_Number;
        $answer = array('id'=>$job->id, 'companyname'=>$job->companyname, 'jobSummary'=>$job->jobSummary, 'role'=>$job->role, 'salaryrange'=>$job->salaryrange, 'in_draft'=>$job->in_draft, 'status'=>$job->status, 'subscriptionplan'=>$job->subscriptionplan, 'location'=>$job->location, 'age_range'=>$job->age_range, 'email'=>$job->email, 'user_id'=>$job->user_id, 'job_description'=>$job->job_description, 'Qualification'=>$job->Qualification, 'ExperienceLength'=>$job->ExperienceLength, 'JobLevel'=>$job->JobLevel, 'SalaryCurrency'=>$job->SalaryCurrency, 'job_code'=>$job->job_code, 'requirements'=>$job->requirements, 'reject_status'=>$job->reject_status, 'created_at'=>$job->created_at, 'end_date'=>$job->end_date, 'picture'=>$user->picture, 'Address'=>$employer->Address, 'company_name'=>$employer->Company_Name, 'industry'=>$employer->Industry, 'office'=>$employer->Telephone_Number);
        array_push($arr, $answer);
        return response()->json(['success'=>$arr]);
       }else{
       return  response()->json(['error'=>'no data']);
       }
    }

    public function editemployeeprofile(Request $request){

        $employee =  Employee::where(['user_id'=>$request->id, 'email'=>$request->email])->first();
        $Riresume  = ridersinstituteresume::where(["employee_id"=>$request->id])->first();


        if($employee && $Riresume){
            $validator = Validator::make($request->all(),[
              //  "resume" => 'required|mimes:pdf,docx,doc',
                'phone_number' =>'required',
                'date_of_birth' =>'required',
                'state' =>'required',
                'lga' =>'required',
                'experience_length' =>'required',
                'gender' =>'required',
                'age' =>'required',
                'role' =>'required',
                'highest_degree' =>'required',
                'skills' =>'required',
                'experience' =>'required'
               ]);

               if($validator->fails()){
                $errors = $validator->errors()->getMessages();
                return ['code'=>'1500', 'error'=>$errors];
               }



          $employee->update([
              'name' => $request->name,
            'phone_number' => $request->phone_number,
            'email' => $request->email,
            'date_of_birth' => $request->date_of_birth,
            'state' => $request->state,
            'lga' => $request->lga,
             'user_id' => $request->id,
             'experience_length' => $request->experience_length,
            'gender' => $request->gender,
             'age' => $request->age,
            'role' => $request->role,
            'highest_degree' => $request->highest_degree,
            'skills' => $request->skills,
            'experience' => $request->experience
          ]);


          if($request->resume != "undefined"){
                    $path =  $request->resume;
                    $totalPages = $this->countPages($path);
                    $clouddata = $this->cloud($path);
                    $url = $clouddata->getSecurePath();
                    $publicId = $clouddata->getPublicId();
                    $Riresume::update([
                        'resumelink' => $url,
                        'numberofpages' => $totalPages,
                        'publicId' => $publicId
                    ]);
              }


        //

        //    $employee->name = $request->name;
        //    $employee->phone_number = $request->phone_number;
        //    $employee->email = $request->email;
        //    $employee->date_of_birth = $request->date_of_birth;
        //    $employee->state = $request->state;
        //    $employee->lga = $request->lga;
        //    $employee->user_id = $request->id;
        //    $employee->experience_length = $request->experience_length;
        //    $employee->gender = $request->gender;
        //    $employee->age = $request->age;
        //    $employee->role = $request->role;
        //    $employee->highest_degree = $request->highest_degree;
        //    $employee->skills = $request->skills;
        //    $employee->experience = $request->experience;
        //    $employee->save();
          return response()->json(['success'=>'you have updated your profile']);
        }else{
          return response()->json(['success'=>'you proflie does not exist']);
        }

    }



    public function applyjob(Request $request){

      $applicant =  AppliedJob::where(["postedjob_id"=>$request->postedjob_id, "user_id"=>$request->user_id])->first();
      $show =  EmployerStatus::where(['posted_id'=>$request->postedjob_id])->first();
      $employee = ridersinstituteresume::where(["employee_id"=>$request->user_id])->first();
      $status = json_decode($show->shortarray);

      if(!$applicant){
      //  $uploadedFileUrl = Cloudinary::uploadFile($request->file('file')->getRealPath())->getSecurePath();
      ///  $name = $request->file('file')->getClientOriginalName();


        // function countPages($path) {
        //   $pdftext = file_get_contents($path);
        //   $num = preg_match_all("/\/Page\W/", $pdftext, $dummy);
        //   return $num;
        // }
        // $path = $request->file('file');
        // $totalPages = countPages($path);


        // if (strpos($name, 'docx') !== false) {
            // $color = explode(".", $name);
            // $uploadedFileUrl = Cloudinary::uploadFile($request->file('file')->getRealPath(),[
            //     "public_id"=>$color[0].'.docx',
            //     "resource_type"=>'image',
            //     "raw_convert" => "aspose",
            //     "pages" => TRUE,
            //     "use_filename" => TRUE,
            //     "unique_filename" => FALSE,
            //     // "eager" => [
            //     //     ["fetch_format" => "auto", "flags" => "attachment:".$color[0], "format" => "Pdf"]
            //     //     ]
            // ]);

        //  $url = $uploadedFileUrl->getSecurePath();
        //  $publicId = $uploadedFileUrl->getPublicId();

           $apply = new AppliedJob();
           $employer_id  = Post_Job::where(['id'=>$request->postedjob_id])->first();
           $apply->postedjob_id = $request->postedjob_id;
           $apply->user_id = $request->user_id;
           $apply->employer_id = $employer_id->user_id;
           $apply->public_id = $employee->publicId;
           $apply->name = $request->name;
           $apply->phone_number = $request->phone_number;
           $apply->qualification = $request->qualification;
           $apply->experiencelenght = $request->experiencelenght;
           $apply->appliant_cv = $employee->resumelink;
           $apply->pages =  $employee->numberofpages;
           $apply->status=$status[0]->name;
            $job = $apply->save();
        if($job){
            return response()->json(['success'=>'your application has been sent']);
        }else{
            return response()->json(['error'=>'your application has not been sent']);
        }

       // }


    //     elseif (strpos($name, 'pdf') !== false) {

    //         $color = explode(".", $name);
    //         $uploadedFileUrl = Cloudinary::uploadFile($request->file('file')->getRealPath(),[
    //             "public_id"=>$color[0].'.pdf',
    //             "pages" => TRUE,
    //             "resource_type"=>'image',
    //             "use_filename" => TRUE,
    //             "unique_filename" => FALSE,
    //             "pages" => TRUE,
    //             // "eager" => [
    //             //     ["fetch_format" => "auto", "flags" => "attachment:".$color[0], "format" => "Pdf"]
    //             //     ]
    //             // "raw_convert" => "aspose"
    //         ]);
    //       $url =  $uploadedFileUrl->getSecurePath();
    //       $publicId =  $uploadedFileUrl->getPublicId();

    //       $apply = new AppliedJob();
    //       $employer_id  = Post_Job::where(['id'=>$request->postedjob_id])->first();
    //       $apply->postedjob_id = $request->postedjob_id;
    //       $apply->user_id = $request->user_id;
    //       $apply->employer_id = $employer_id->user_id;
    //       $apply->public_id = $publicId;
    //       $apply->name = $request->name;
    //       $apply->phone_number = $request->phone_number;
    //       $apply->qualification = $request->qualification;
    //       $apply->experiencelenght = $request->experiencelenght;
    //       $apply->appliant_cv = $url;
    //       $apply->pages =  $totalPages;
    //       $apply->status=$status[0]->name;
    //        $job = $apply->save();
    //    if($job){
    //        return response()->json(['success'=>'your application has been sent']);
    //    }else{
    //        return response()->json(['error'=>'your application has not been sent']);
    //    }

    //     }



      }else{
        return response()->json(['error'=>'you have applied for this job before']);
      }


    }

     public function appliedEmployee($id){
         $user = User::find($id);
         //employeeApplied
        //  $user->applicantinfo

        //   return  response()->json();
        return new UserEmployee($user);
     }
    public function employeeapplied($id){
        $user = User::find($id);
        if ($user->Role == "Employee") {
            $answer = AppliedEmployee::collection($user->applicantinfo);
            return response()->json(["success"=>$answer]);
        } else {
            return response()->json(["error"=>"you are not an employee"]);
        }




    }

    public function verificationinfo(Request $request){
          $id = intval($request->id);
        $employee = Employee::where(["user_id"=>$id])->first();
        if($employee){
                           $messages = json_decode($request->array);
                 $employee->nin_slipld = $messages[0]->publicid;
                 $employee->nin_slippage = $messages[0]->pages;
                 $employee->rider_cardId = $messages[1]->publicid;
                 $employee->rider_cardpage = $messages[1]->pages;
                $employee->driving_licenseId = $messages[2]->publicid;
                $employee->driving_licensepage = $messages[2]->pages;
                $employee->prove_of_addressId = $messages[3]->publicid;
                $employee->prove_of_addresspage = $messages[3]->pages;
                 $employee->passport_photographId = $messages[4]->publicid;
                 $employee->passport_photographpage = $messages[4]->pages;
                  $employee->nin_slip = $messages[0]->link;
                  $employee->rider_card =  $messages[1]->link;
                  $employee->driving_license = $messages[2]->link;
                  $employee->prove_of_address = $messages[3]->link;
                  $employee->passport_photograph = $messages[4]->link;
                  $employee->save();
                  return response()->json(["success"=>"your documents have been saved"]);
            }

    }



    public function stephentest()
    {
       $all = new AuthorsController;
      return response()->json($all->show(User::first(), 100));

    }
    

    public function paginate($items, $perPage = 4, $page = null){
    $page = $page ?: (Paginator::resolveCurrentPage() ?: 1);
    $total = count($items);
    $currentpage = $page;
    $offset = ($currentpage * $perPage) - $perPage ;
    $itemstoshow = array_slice($items , $offset , $perPage);
    return new LengthAwarePaginator($itemstoshow ,$total ,$perPage);
} 


}
