<?php

namespace App\Http\Controllers;

use App\Http\Resources\adminallpostedjobs;
use App\Http\Resources\adminuserdata;
use App\Http\Resources\AllEmployeeHired;
use App\Http\Resources\Post_JobFilterResource;
use App\Http\Resources\Post_jobResource;
use App\Models\Adminreason;
use App\Models\AppliedJob;
use App\Models\Downloadplan;
use App\Models\Employee;
use App\Models\EmployeeHired;
use App\Models\Employer;
use App\Models\EmployerPlan;
use App\Models\ExitAdminreason;
use App\Models\ExitreasonEmployer;
use App\Models\Payment;
use App\Models\Post_Job;
use App\Models\User;
use App\Models\VerifieldEmployee;
use Carbon\Carbon;
use Illuminate\Pagination\Paginator;
use Illuminate\Pagination\LengthAwarePaginator;
use FontLib\Table\Type\post;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use MailchimpTransactional\ApiClient;
class Admin extends Controller
{


    public function adminregister(Request $request){
        $validator = Validator::make($request->all(),[
            "name" => 'required',
            "email" => 'required|email|unique:users',
            'password'=>'required|confirmed|min:8',
           ]);

           if($validator->fails()){
            $errors = $validator->errors()->getMessages();
            return ['code'=>'1500', 'error'=>$errors];
           }

           $user =  new User();
           $user->name = $request->name;
           $user->email = $request->email;
           $user->Role = "SuperAdmin";
           $user->verification_code = sha1(time());
           $user->password = Hash::make($request->password);
            $user->save();


                    Controller::SendEmail($user->name, $user->email, $user->verification_code);


                          return  response()->json(['success'=>'your accout has been created please check your email']);

    }




    public function adminlogin(Request $request){
        $validator = Validator::make($request->all(),[
            "email" => 'required|email',
            'password'=>'required|min:8',
           ]);

           if($validator->fails()){
            $errors = $validator->errors()->getMessages();
            return ['code'=>'1500', 'error'=>$errors];
           }

        //    $credentials = $request->only('email', 'password');
                 $email =  preg_replace("/\s+/", "", $request->email);
            $user = User::where(['email'=>$email])->first();

            $pass =  preg_replace("/\s+/", "", $request->password);
           if($user && Hash::check($pass, $user->password)){


             $token =  $user->createToken('my-app-token')->plainTextToken;

             if($user->is_verified == 0 && $user->suspensed == 0){
                return ['error'=>'please go and verify your account'];
            }else if($user->is_verified == 1 && $user->suspensed == 0){
                $response = [
                    'user'=>[
                     'id'=>$user->id,
                    'name'=>$user->name,
                    'email'=>$user->email,
                    'address'=>$user->Address,
                     'Role'=>$user->Role,
                     "suspensed"=>$user->suspensed,
                     'picture'=>$user->picture
                    ],
                     'token'=>$token
                ];
                return response($response, 201);
            }else if ($user->is_verified == 1 && $user->suspensed == 1){
              return response()->json(['error'=>'your account is inactive']);
            }


          }else{
            return response()->json(['error'=>'wrong password or email']);
          }
      }

     public function allpostedtotal($page){
        $user = $this->getusers();
      if($user->Role === "SuperAdmin" || $user->Role === "Admin"){
          $post =  Post_Job::whereNotNull("position")->whereNotNull("job_code")->get();
      $data  = adminallpostedjobs::collection($post)->resolve();
     // $page = 1;
        $answer = $this->paginate($data, 10, $page);
      return response()->json(["success"=>$answer]);

      }else{
          return response()->json(['error'=>"you are not an admin"]);
      }

      }

      public function allpostedjob($page){
        $user = $this->getusers();
      if($user->Role === "SuperAdmin" || $user->Role === "Admin"){
        $post = Post_Job::where(["position"=>"Awaiting Approval"])->get();
      $data  = adminallpostedjobs::collection($post)->resolve();
       $answer = $this->paginate($data, 10, $page);
      return response()->json(["success"=>$answer]);

      }else{
          return response()->json(['error'=>"you are not an admin"]);
      }

      }

      public function unapprovedjobsposted(Request $request){
          //   $user = User::find($request->id);
          $user = $this->getusers();
          if ($user->Role === "SuperAdmin" || $user->Role === "Admin") {
              $post = Post_Job::find($request->postedid);
              $post->position = $request->status;
              $post->save();
              $postdata = Post_Job::all();
              $fetchdata  = adminallpostedjobs::collection($postdata);
              return response()->json(['success'=>'this job has been unapproved ', "data"=>$fetchdata]);
          }
      }
      
      
          public function allpostedUnapproved($page){
        $user = $this->getusers();
      if($user->Role === "SuperAdmin" || $user->Role === "Admin"){
          $post =  Post_Job::where(["position"=>"Unapproved"])->whereNotNull("job_code")->get();
      $data  = adminallpostedjobs::collection($post)->resolve();
     // $page = 1;
        $answer = $this->paginate($data, 10, $page);
      return response()->json(["success"=>$answer]);

      }else{
          return response()->json(['error'=>"you are not an admin"]);
      }

      }
      
     public function allpostedApprovedJobs($page){
        $user = $this->getusers();
      if($user->Role === "SuperAdmin" || $user->Role === "Admin"){
          $post =  Post_Job::where(["position"=>"Active"])->whereNotNull("job_code")->get();
      $data  = adminallpostedjobs::collection($post)->resolve();
     // $page = 1;
        $answer = $this->paginate($data, 10, $page);
      return response()->json(["success"=>$answer]);

      }else{
          return response()->json(['error'=>"you are not an admin"]);
      }

      }


      public function approvedjobsposted(Request $request){
        //   $user = User::find($request->id);
           $user = $this->getusers();
          if($user->Role === "SuperAdmin" || $user->Role === "Admin"){
             $now = Carbon::now();
             $post = Post_Job::find($request->postedid);
             $person = User::where(['email'=>$post->email])->first();
             $planname = EmployerPlan::where(['nameofplan'=>$post->subscriptionplan])->first();
             $numberofdays = intval($planname->numberofemployee);
            $post->created_at = $now;
             $post->end_date = $now->addDay($numberofdays);
             $post->position = $request->status;
             $post->save();
             $postdata = Post_Job::all();
             Controller::Approvedanddecline($person->name, $post->job_code, $post->email);
             $fetchdata  = adminallpostedjobs::collection($postdata);

                                            $messages =  Employee::where(function($query) use($post){
                                                $age =  explode("-", $post->age_range);
                                                $state = explode(",", $post->location);
                                                // $Length = explode("-", $request->ExperienceLength);
                                                 $query->Where('role', 'LIKE', '%'.$post->role.'%')
                                                //   ->orWhere('qualification', 'LIKE', '%'.$request->Qualification.'%')
                                                  ->orWhere('experience_length', 'LIKE', '%'.$post->ExperienceLength.'%')
                                                   ->whereIn('state', $state)
                                               //   ->orWhere('joblevel', 'LIKE', '%'.$post->JobLevel.'%')
                                                   ->whereBetween('age',[intval($age[0]), intval($age[1])] );
                                            })->get();

                        $i = 0;
                        $len = count($messages);
                         foreach ($messages as $one){
                         if ($i !== $len - 1) {
                         // sleep(1);

                        Controller::JobEmail($post->id, $post->role, $one->email, $one->name, $post->companyname, $post->location);

                         } else if ($i == $len - 1) {
                              return response()->json(['success'=>'this job has been approved', "data"=>$fetchdata]);
                             }
                             $i++;

                                    }


          }else{
            return response()->json(['error'=>"you are not an admin"]);
        }

      }


      public function adminadduser(Request $request){
        $validator = Validator::make($request->all(),[
            "name" => 'required',
            "email" => 'required|email|unique:users',
            "Role"=>'required',
            'password'=>'required|confirmed|min:8',
           ]);

           if($validator->fails()){
            $errors = $validator->errors()->getMessages();
            return ['code'=>'1500', 'error'=>$errors];
           }
            if($request->Role === "SuperAdmin" || $request->Role === "Admin"){
                $user =  new User();
                $user->name = $request->name;
                $user->email = $request->email;
                $user->Role = $request->Role;
                $user->verification_code = sha1(time());
                $user->is_verified = 1;
                $user->suspensed = 0;
                $user->password = Hash::make($request->password);
                 $user->save();
                if ($user) {
                    $pay = new Payment();
                    $pay->user_id = $user->id;
                    $pay->email =  $user->email;
                    $pay->subscription = '0';
                    $pay->verificationmessage = '';
                    $pay->referencecode = '';
                    $pay->save();
                }
                $users = User::orderBy('id', 'DESC')->get();
                // $arr = [];
                // foreach ($users as  $user) {
                //     $user->id;
                //     $user->name;
                //     $user->role;
                //     $user->email;
                //     $user->is_verified;
                //     $user->suspensed;
                //     $obj = array("id"=>$user->id, "name"=>$user->name, "role"=>$user->Role, "email"=>$user->email, 'active'=>$user->is_verified, "suspensed"=>$user->suspensed, "picture"=>$user->picture);
                //     array_push($arr, $obj);
                // }
                $arr = adminuserdata::collection($users);
                return  response()->json(['success'=>'an '.$request->Role.' account has been created', "data"=>$arr]);

            }else{
                $user =  new User();
                $user->name = $request->name;
                $user->email = $request->email;
                $user->Role = $request->Role;
                $user->verification_code = sha1(time());
                $user->password = Hash::make($request->password);
                 $user->save();
                if ($user) {
                    $pay = new Payment();
                    $pay->user_id = $user->id;
                    $pay->email =  $user->email;
                    $pay->subscription = '0';
                    $pay->verificationmessage = '';
                    $pay->referencecode = '';
                    $pay->save();
                }

           Controller::SendEmail($user->name, $user->email, $user->verification_code);

               $users = User::orderBy('id', 'DESC')->get();
                // $arr = [];
                // foreach ($users as  $user) {
                //     $user->id;
                //     $user->name;
                //     $user->role;
                //     $user->email;
                //     $user->is_verified;
                //     $user->suspensed;
                //     $obj = array("id"=>$user->id, "name"=>$user->name, "role"=>$user->Role, "email"=>$user->email, 'active'=>$user->is_verified, "suspensed"=>$user->suspensed, "picture"=>$user->picture);
                //     array_push($arr, $obj);
                // }

                $arr = adminuserdata::collection($users);

                return  response()->json(['success'=>'an '.$request->Role.' account has been created', "data"=>$arr]);


            }

      }
      
   public function totalemployer($page){
    $one =  $this->getusers();
    if ($one->Role === "SuperAdmin" || $one->Role === "Admin") {
      //  $users = User::orderBy('id', 'DESC')->get();
       $users =  User::where(["Role"=>"Employer"])->get();
         $arr = adminuserdata::collection($users)->resolve();
          $answer = $this->paginate($arr, 10, $page);
        return response()->json(["success"=>$answer]);
    }else{
       return response()->json(["error"=>"you are not an admin"]);
    }
}

public function activeadmin($page){
    $one =  $this->getusers();
    if ($one->Role === "SuperAdmin" || $one->Role === "Admin") {
       $users =  User::where("Role", "!=", "Employee")->where("Role", "!=", "Employer")->get();
         $arr = adminuserdata::collection($users)->resolve();
          $answer = $this->paginate($arr, 10, $page);
        return response()->json(["success"=>$answer]);
    }else{
       return response()->json(["error"=>"you are not an admin"]);
    }
}

public function admincreate($page){
    $one =  $this->getusers();
    if ($one->Role === "SuperAdmin" || $one->Role === "Admin") {
       $users =  User::where(["Role"=>"Employee"])->get();
         $arr = adminuserdata::collection($users)->resolve();
          $answer = $this->paginate($arr, 10, $page);
        return response()->json(["success"=>$answer]);
    }else{
       return response()->json(["error"=>"you are not an admin"]);
    }
}

public function activeemployer($page){
    $one =  $this->getusers();
    if ($one->Role === "SuperAdmin" || $one->Role === "Admin") {
       $users =  User::where(["Role"=>"Employer","is_verified"=>1, "suspensed"=>0])->get();
         $arr = adminuserdata::collection($users)->resolve();
          $answer = $this->paginate($arr, 10, $page);
        return response()->json(["success"=>$answer]);
    }else{
       return response()->json(["error"=>"you are not an admin"]);
    }
}


public function InactiveEmployer($page){
    $one =  $this->getusers();
    if ($one->Role === "SuperAdmin" || $one->Role === "Admin") {
       $users =  User::where(["Role"=>"Employer","is_verified"=>0, "suspensed"=>0])->get();
         $arr = adminuserdata::collection($users)->resolve();
          $answer = $this->paginate($arr, 10, $page);
        return response()->json(["success"=>$answer]);
    }else{
       return response()->json(["error"=>"you are not an admin"]);
    }
}


public function activeemployee($page){
      $one =  $this->getusers();
    if ($one->Role === "SuperAdmin" || $one->Role === "Admin") {
       $users =  User::where(["Role"=>"Employee", "is_verified"=>1, "suspensed"=>0])->get();
         $arr = adminuserdata::collection($users)->resolve();
          $answer = $this->paginate($arr, 10, $page);
        return response()->json(["success"=>$answer]);
    }else{
       return response()->json(["error"=>"you are not an admin"]);
    }
}

public function Inactiveemployee($page){
      $one =  $this->getusers();
    if ($one->Role === "SuperAdmin" || $one->Role === "Admin") {
       $users =  User::where(["Role"=>"Employee", "is_verified"=>0, "suspensed"=>0])->get();
         $arr = adminuserdata::collection($users)->resolve();
          $answer = $this->paginate($arr, 10, $page);
        return response()->json(["success"=>$answer]);
    }else{
       return response()->json(["error"=>"you are not an admin"]);
    }
}



public function edituserinfo(Request $request){

  if($request->password != "" || $request->password  != null   ){

     $validator = Validator::make($request->all(),[
        "name" => 'required',
        "role" => 'required',
        'password'=>'required|confirmed|min:8',
       ]);

       if($validator->fails()){
        $errors = $validator->errors()->getMessages();
        return ['code'=>'1500', 'error'=>$errors];
       }
       //$user = User::find($request->id);
       $user = $this->getusers();
       $user->update([
        'name' => $request->name,
         'Role' => $request->role,
        'password' => Hash::make($request->password)
       ]);
        $users = User::orderBy('id', 'DESC')->get();
        $arr = adminuserdata::collection($users);
    return response()->json(['success'=>"changes have been made to this account", "data"=>$arr]);
  }else if($request->password == "" || $request->password  == null ){

    $validator = Validator::make($request->all(),[
        "name" => 'required',
        "role" => 'required',
       ]);

       if($validator->fails()){
        $errors = $validator->errors()->getMessages();
        return ['code'=>'1500', 'error'=>$errors];
       }
       $user = User::find($request->id);
       $user->name = $request->name;
            $user->Role = $request->role;
            $user->save();

            $users = User::orderBy('id', 'DESC')->get();
            $arr = adminuserdata::collection($users);
            return response()->json(['success'=>'changes have been made to this account', "data"=>$arr]);
  }
}

public function suspensedaccount (Request $request){
   $user = User::orderBy('id', 'DESC')->get();
   $user->suspensed = 1;
   $user->save();
   $users = User::orderBy('id', 'DESC')->get();
//    $arr = [];
//    foreach ($users as  $user) {
//        $user->id;
//        $user->name;
//        $user->role;
//        $user->email;
//        $user->is_verified;
//        $user->suspensed;
//        $obj = array("id"=>$user->id, "name"=>$user->name, "role"=>$user->Role, "email"=>$user->email, 'active'=>$user->is_verified, "suspensed"=>$user->suspensed, "picture"=>$user->picture);
//        array_push($arr, $obj);
//    }
  $arr = adminuserdata::collection($users);
   return response()->json(["success"=>$user->name."has been suspended", "array"=>$arr]);
}

public function adminhirestatus(Request $request){
  $apply = AppliedJob::find($request->id);
  if($apply && $apply->status === "Hired"){
    $postid = intval($request->postid);
     $post = Post_Job::find($postid);
    $employeehired = EmployeeHired::where(["employee_id"=>$request->employee_id, "employer_id"=>$post->user_id])->first();
    if($employeehired){
        //decisiondate
        $employeehired->employer_id = $post->user_id;
        $employeehired->employee_id = $request->employee_id;
        $employeehired->posted_id =  $postid;
        $employeehired->status = $request->reason;
        $employeehired->reason_by_employer =  $request->reason;
        $employeehired->explaination = $request->explaination;
        $employeehired->end_data = $request->decisiondate;
        $apply->status = $request->reason;
        $apply->save();
        $employeehired->save();
        $answer = new Post_JobFilterResource($post);
     return response()->json(["success"=>"the applicant status has been updated", "array"=>$answer]);
    }else{
        return response()->json(["error"=>"this person does not exist"]);
    }

  }else{
      return response()->json(["error"=>"sorry you can only dismis hired applicant"]);
  }

}

public function verifieldusers ($page){
    $user = $this->getusers();

    if($user->Role === "SuperAdmin" || $user->Role === "Admin"){
       // $employee = Employee::orderBy('id', 'DESC')->get();
       $employee = Employee::join('users', 'employees.user_id', '=', 'users.id')
            ->where('users.is_verified',  1)
            ->where('employees.approved_by_ri', '!=', 1)
            ->get();
          $data = AllEmployeeHired::collection($employee)->resolve();
           $answer = $this->paginate($data, 10, $page);
            return response()->json(["success"=>$answer]);

    }else{
        return response()->json(["error"=>"your not an Admin"]);
    }
}

public function Approvedadminusers ($page){
    $user = $this->getusers();

    if($user->Role === "SuperAdmin" || $user->Role === "Admin"){
       // $employee = Employee::orderBy('id', 'DESC')->get();
       $employee = Employee::join('users', 'employees.user_id', '=', 'users.id')
            ->where('users.is_verified',  1)
            ->where('employees.approved_by_ri',  1)
            ->get();
          $data = AllEmployeeHired::collection($employee)->resolve();
           $answer = $this->paginate($data, 10, $page);
            return response()->json(["success"=>$answer]);

    }else{
        return response()->json(["error"=>"your not an Admin"]);
    }
}

public function employeeverified(Request $request){
    $user = $this->getusers();
    if($user->Role === "SuperAdmin"){
        $employee = Employee::where(["user_id"=>$request->employee_id])->first();
        if($employee){
            if($request->nin == true && $request->card == true && $request->license == true && $request->address == true && $request->passport == true){
              $vemployee = VerifieldEmployee::where(['employee_id'=>$request->employee_id])->first();
               if(!$vemployee){
                  $verifieldemployee = new VerifieldEmployee();
                  $verifieldemployee->employee_id = $request->employee_id;
                    $verifieldemployee->nin_slippage = $request->nin;
                    $verifieldemployee->rider_cardpage = $request->card;
                    $verifieldemployee->driving_licensepage = $request->license;
                    $verifieldemployee->prove_of_addresspage = $request->address;
                    $verifieldemployee->passport_photographpage = $request->passport;
                    $verifieldemployee->status = 1;
                    $verifieldemployee->save();
                    $employee->approved_by_ri = 1;
                    $employee->save();
                    return response()->json(["success"=>"this employee have been verifield"]);
               }else{
                   return response()->json(['error'=>"the person is already verifield"]);
               }


            }else{

                $vemployee = VerifieldEmployee::where(['employee_id'=>$request->employee_id])->first();
                if(!$vemployee){
                   $verifieldemployee = new VerifieldEmployee();
                   $verifieldemployee->employee_id = $request->employee_id;
                     $verifieldemployee->nin_slippage = $request->nin;
                     $verifieldemployee->rider_cardpage = $request->card;
                     $verifieldemployee->driving_licensepage = $request->license;
                     $verifieldemployee->prove_of_addresspage = $request->address;
                     $verifieldemployee->passport_photographpage = $request->passport;
                     $verifieldemployee->status = false;
                     $verifieldemployee->save();
                     $employee->approved_by_ri = false;
                     $employee->save();
                     return response()->json(["success"=>"this employee has not been verified"]);
                }else{
                    return response()->json(['error'=>"the person is already verifield"]);
                }
            }

        }

    }else{
        return response()->json(['error'=>'your are not an Admin']);
    }

}

public function getallplans (){
    $user = $this->getusers();
    if($user->Role === "SuperAdmin"){
         $employerplan = EmployerPlan::orderBy('id', 'asc')->get();
         return response()->json(['success'=>$employerplan]);
    }else{
        return response()->json(['error'=>'you are not an Admin']);
    }
}


  public function plansbyadmin(Request $request){
      $user = $this->getusers();
      if($user->Role === "SuperAdmin"){
          if($request->status === 'Add'){
       $exitplan = $request->exit_reason == true?1:0;
       $numdownload = $request->download == true?1:0;
          $employerplan =  EmployerPlan::create([
                "nameofplan"=>$request->nameofplan,
                  "numberofemployee"=>$request->numberofemployee,
                  "pricepermonth"=>$request->pricepermonth,
                  "description"=>$request->description,
                  'exit_reason'=>$exitplan,
                  'download'=>$numdownload,
                  'number_of_download'=>$request->numofdw
            ]);
            if($employerplan){
                $plans =  EmployerPlan::all();
               return response()->json(["success"=>'a plan has been added', "data"=>$plans]);
            }
          }


      }else{
          return response()->json(['error'=>'you are not an Admin']);
      }
  }

  public function plansbyedit(Request $request){
    $user = $this->getusers();
    if ($user->Role === "SuperAdmin") {
        $num = intval($request->employerplanid);
        $employerplan = EmployerPlan::find($num);
        $employerplan->update([
            'nameofplan' => $request->nameofplan,
            'numberofemployee' => $request->numberofemployee,
            'pricepermonth' => $request->pricepermonth,
            'description' => $request->description,
            'exit_reason'=> $request->exit_reason,
            'download'=>$request->download,
            'number_of_download'=>$request->numofdw
        ]);
        $plans =  EmployerPlan::all();
        return response()->json(["success"=>'the plan has been edited', "data"=>$plans]);
    }else{
        return response()->json(['error'=>'you are not an Admin']);
    }
  }

  public function AdminDownload(Request $request){
    $validator = Validator::make($request->all(),[
        "nameofplan" => 'required|alpha',
        "number_of_download" => 'required|integer',
        "amount"=>'required|integer',
        'explaination'=>'required',
       ]);

       if($validator->fails()){
        $errors = $validator->errors()->getMessages();
        return ['code'=>'1500', 'error'=>$errors];
       }
       $user = $this->getusers();
       if($user->Role == "SuperAdmin" || $user->Role == "Admin"){
        Downloadplan::create($request->all());
        $data = Downloadplan::orderBy('id', 'desc')->get();
        return response()->json(['success'=>'you have created a download plan', 'data'=>$data]);
       }else{
        return response()->json(['error'=>'you are not an Admin']);
       }
  }

  public function AdminDownloadall(){
    $user = $this->getusers();
      if ($user->Role == "SuperAdmin" || $user->Role == "Admin") {
          $data = Downloadplan::orderBy('id', 'desc')->get();
          return response()->json(['success'=>$data]);
      }else{
        return response()->json(['error'=>'you are not an Admin']);
       }
  }

  public function AdminDownloadEdit(Request $request){
    $validator = Validator::make($request->all(),[
        "nameofplan" => 'required|alpha',
        "number_of_download" => 'required|integer',
        "amount"=>'required|integer',
        'explaination'=>'required',
       ]);

       if($validator->fails()){
        $errors = $validator->errors()->getMessages();
        return ['code'=>'1500', 'error'=>$errors];
       }
       $user = $this->getusers();
       if($user->Role == "SuperAdmin" || $user->Role == "Admin"){
          $downloadplan =  Downloadplan::find($request->id);
          $data = Downloadplan::orderBy('id', 'desc')->get();
          $downloadplan->update([
            'nameofplan'=>$request->nameofplan,
           'number_of_download'=>$request->number_of_download,
           'amount'=>$request->amount,
           'explaination'=>$request->explaination
          ]);
          response()->json(['success'=>'you have five updated the download plan', 'data'=>$data]);

       }else{
        return response()->json(['error'=>'you are not an Admin']);
       }
  }

  public function AdminDownloadDelete(Request $request){
    $validator = Validator::make($request->all(),[
        "id"=>'required|integer',
       ]);

       if($validator->fails()){
        $errors = $validator->errors()->getMessages();
        return ['code'=>'1500', 'error'=>$errors];
       }
   $user = $this->getusers();
   if($user->Role == "SuperAdmin" || $user->Role == "Admin"){
    $download =  Downloadplan::find($request->id)->delete();
    $data = Downloadplan::orderBy('id', 'desc')->get();
    return response()->json(['success'=>'your download plan has been delete', 'data'=>$data]);
   }else{
    return response()->json(['error'=>'you are not an Admin']);
   }


  }

  public function plansbydelete(Request $request){
    $num = intval($request->employerplanid);
    $employerplan = EmployerPlan::find($num);
    $employerplan->delete();
    $plans =  EmployerPlan::all();
    return response()->json(["success"=>'the plan has been delete', "data"=>$plans]);

  }

  public function exitreason(Request $request){
        $data = Adminreason::select('*')->get();
        if(count($data) == 0){
            Adminreason::create([
                "reason"=>$request->array
            ]);
            $adminreason = Adminreason::all();
          return response()->json(["success"=>"your reasons has been added", "source"=>$adminreason ]);
        }


  }

  public function adminuserupdate(Request $request){
      $user = $this->getusers();
      if ($user->Role == "SuperAdmin" || $user->Role == "Admin") {
          $id =  intval($request->id);
          $userupdate = User::find($id);
          $userupdate->is_verified = 1;
                $userupdate->save();
          $users = User::orderBy('id', 'DESC')->get();
          $arr = adminuserdata::collection($users);
         return response()->json(['success'=>'this user account has been verified', 'data'=>$arr]);
      }else{
        return response()->json(['error'=>"you are not an Admin"]);
      }
  }


  public function admineditreason(Request $request)
  {
    $user = $this->getusers();
    if ($user->Role == "SuperAdmin" || $user->Role == "Admin") {
        $id =  intval($request->id);
        $adminreason =  Adminreason::find($id);
       // $recent = json_encode( $request->array);
        $adminreason->update([
            "reason"=>$request->array
           ]);
        $adminall = Adminreason::all();
        return response()->json(["success"=>"the reason have been updated", 'data'=>$adminall ]);
    }else{
        return response()->json(['error'=>"you are not an Admin"]);
    }
}

   public function admintotals(){
       $user = $this->getusers();
       if($user->Role == "SuperAdmin" || $user->Role == "Admin"){
        $employer = count(Employer::orderBy('id', 'DESC')->get());
        $employee = count(Employee::orderBy('id', 'DESC')->get());
        $jobs = count(Post_Job::orderBy('id', 'DESC')->get());
        return response()->json(['employer'=>$employer, 'employee'=>$employee, 'jobs'=>$jobs]);
       }else{
           return response()->json(['error'=>'you are not admin']);
       }
   }
  public function getreason(){
  $user = $this->getusers();
  if($user->Role == "SuperAdmin" || $user->Role == "Admin"){
       $adminreason = Adminreason::orderBy('id', 'DESC')->get();
       return response()->json(["success"=>$adminreason]);
  }
}

    public function paginate($items, $perPage = 4, $page = null){
    $page = $page ?: (Paginator::resolveCurrentPage() ?: 1);
    $total = count($items);
    $currentpage = $page;
    $offset = ($currentpage * $perPage) - $perPage ;
    $itemstoshow = array_slice($items , $offset , $perPage);
    return new LengthAwarePaginator($itemstoshow ,$total ,$perPage);
} 



}





