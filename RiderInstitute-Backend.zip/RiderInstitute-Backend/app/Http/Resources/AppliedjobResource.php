<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class AppliedjobResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        // 'name',
        // 'postedjob_id',
        // 'user_id',
        // 'phone_number',
        // 'employer_id',
        // 'qualification',
        // 'experiencelenght',
        // return parent::toArray($request);
        return [
            'id'=>$this->id,
            'name'=> $this->name,
            'postedjob_id' => $this->postedjob_id,
            'user_id'=>$this->user_id,
            'phone_number' => $this->phone_number,
            'qualification' => $this->qualification,
            'experiencelenght' => $this->experiencelenght,
        ];
    }
}
