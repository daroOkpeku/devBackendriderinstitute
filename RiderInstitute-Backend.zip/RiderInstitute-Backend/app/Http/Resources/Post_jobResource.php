<?php

namespace App\Http\Resources;

use App\Models\AppliedJob;
use Illuminate\Http\Resources\Json\JsonResource;

class Post_jobResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        // return parent::toArray($request);
        // $user = $this->whenLoaded('user');
        return [
            'id'=>$this->id,
            'role'=> $this->role,
            'status'=>$this->status,
            'statusofsub'=>$this->statusofsub,
            'created_at'=> $this->created_at,
            'updated_at'=> $this->updated_at,
            'end_date'=> $this->end_date,
            'count'=> count(AppliedjobResource::collection(AppliedJob::where(["postedjob_id"=>$this->id])->get())),
        ];
    }
}
// $this->when($this->status === 'Active',function(){})
