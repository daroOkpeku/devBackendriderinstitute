<?php

namespace App\Http\Resources;

use App\Models\Employer;
use App\Models\Post_Job;
use App\Models\User;
use Illuminate\Http\Resources\Json\JsonResource;

class AppliedEmployeeJob extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        // return parent::toArray($request);
        return [
            'id'=>$this->id,
            'postedjob_id'=>$this->postedjob_id,
            'user_id'=>$this->user_id,
            'status'=> $this->status,
            'appliant_cv'=>$this->appliant_cv,
            'created_at'=>$this->created_at,
            'employer_info'=> User::where(['id'=>$this->employer_id])->first(),
            'employer'=>Employer::where(['user_id'=>$this->employer_id])->first(),
            'posted'=>Post_Job::where(['id'=>$this->postedjob_id])->first(),
        ];
    }
}
