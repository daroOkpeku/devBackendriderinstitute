<?php

namespace App\Http\Resources;

use App\Models\AppliedJob;
use App\Models\Employee;
use App\Models\EmployerPlan;
use Illuminate\Http\Resources\Json\JsonResource;

class Post_JobFilterResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
       return [
           'id'=>$this->id,
           'user_id'=>$this->user_id,
        //    "exit_reason"=>EmployerPlan::where(["nameofplan"=>$this->subscriptionplan])->first()->exit_reason,
            // 'user'=>userinfoResource::collection($this->ViewAppliedEmployee),
            "applied"=>AppliedEmployeeResource::collection($this->AppliedEmployee),
       ];
    }
}
