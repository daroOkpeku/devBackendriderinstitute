<?php

namespace App\Http\Resources;

use App\Models\EmployerPlan;
use Illuminate\Http\Resources\Json\JsonResource;

class allPayHistory extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        // $plan =  EmployerPlan::where(['nameofplan'=>$pay->subscriptionname])->first();
        // $number = intval($plan->numberofemployee);
        // $expireddate = $pay->updated_at->addDay($number);
        // $createddate =  $pay->updated_at;
        // $subscriptionname = $pay->subscriptionname;
        // $carexpired =  Carbon::createFromFormat('Y-m-d H:i:s', $expireddate)->toDateTimeString();
        // $carcreate =  Carbon::createFromFormat('Y-m-d H:i:s', $createddate)->toDateTimeString();
        //  $sam = array('subscriptionname'=>$subscriptionname, 'money'=>$pay->subscription, 'expireddate'=>$carexpired, 'createddate'=>$carcreate);
        // array_push($steve, $sam);

        return [
            "subscriptionname"=>$this->subscriptionname,
            "expireddate"=>$this->updated_at->addDay(intval(EmployerPlan::where(['nameofplan'=>$this->subscriptionname === NULL?" ":$this->subscriptionname])->first()->numberofemployee??"")),
            "money"=>$this->subscription,
            "createddate"=>$this->updated_at,
        ];
    }
}
