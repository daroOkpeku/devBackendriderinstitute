<?php

namespace App\Http\Resources;

use App\Models\Employee;
use App\Models\Employer;
use Illuminate\Http\Resources\Json\JsonResource;

class adminuserdata extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {


        return [
            "id"=>$this->id,
          "name"=>$this->name,
          "role"=>$this->Role,
          "email"=>$this->email,
         'active'=>$this->is_verified,
          "suspensed"=>$this->suspensed,
           "picture"=>$this->picture,
           "more"=>Employee::where(['user_id'=>$this->id])->first()?Employee::where(['user_id'=>$this->id])->first():Employer::where(["user_id"=>$this->id])->first(),
        ];
    }
}
