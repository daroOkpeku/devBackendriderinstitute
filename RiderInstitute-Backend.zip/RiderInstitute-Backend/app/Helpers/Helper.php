<?php
namespace App\Helpers;


class Helper {

    public static function Help($model, $row, $length = 4, $prefix){

       $data =  $model::orderBy('id', 'desc')->first();

       if(!$data){
           $o_length = $length;
           $last_number = '';

       }else{
           $code = substr($data->$row, strlen($prefix)+1);
           $code = random_int(000, 999);
           $ran = random_int(1, 7);
            $actual_last_number = ($code/1)*$ran;
            $increament_last_number = $actual_last_number+1;
            $last_number_length = strlen($increament_last_number);
            $og_length = $length - $last_number_length;
            $last_number =   $increament_last_number;
       }
       $zero = '';
       for ($i=0; $i < $og_length ; $i++) {
        $zero.="0";
       }

       return $prefix.'-'.$zero.$last_number;

    }
}

?>
