<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Downloadplan extends Model
{
    use HasFactory;

    protected $fillable = [
        'nameofplan',
        'number_of_download',
        'amount',
        'explaination'
    ];
}
