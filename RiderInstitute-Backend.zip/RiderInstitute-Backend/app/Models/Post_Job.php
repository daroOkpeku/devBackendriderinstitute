<?php

namespace App\Models;
// use Laravel\Scout\Searchable;
use Nicolaslopezj\Searchable\SearchableTrait;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Post_Job extends Model
{
    //install "nicolaslopezj/searchable": "1.*"
    //to be able to do fulltext search
    use HasFactory;
    //  use Searchable;
      use SearchableTrait;
      
      
       protected $searchable  = [
      "columns"=>[
          //"post__jobs.salaryrange"=>10,
         // "post__jobs.end_date"=>10,
         // "post__jobs.created_at"=>10,
         // "post__jobs.age_range"=>10,
          //"post__jobs.role"=>10,
          "post__jobs.job_code"=>10,
         // "post__jobs.id"=> 10,
      ]
    ];
      
    protected $fillable = [
        'companyname',
        'jobSummary',
        'role',
        'salaryrange',
        // 'expired_status',
        // 'approved_status',
        // 'indraft',
        // 'statusofsub',
        'subscriptionplan',
        'location',
        'age_range',
        'email',
        'user_id',
        'job_description',
        'Qualification',
        'ExperienceLength',
        'JobLevel',
        'SalaryCurrency',
        'job_code',
        'requirements',
        'figure',
        'changestatus',
         'statusofsub',
         'indraft',
        'reject_status',
        'end_date'
    ];


    public function user() {
        return $this->hasOne(User::class);
    }
    public function qEmployee() {
        return $this->hasMany(Qualifield_Employee::class,'posted_id', 'id');
    }
     //working
    // many to many connnection
    // it is connecting  the post_job, qualifield_employee and rider model
    // if u want to do many connection for rider model u have to do  return $this->belongsToMany(Post_job::class, 'qualifield__employees', 'posted_id', 'rider_id');
    // qualifield__employees table is what is connecting the two tables together using  posted_id, rider_id
    public function ridersq(){
        return $this->belongsToMany(Rider::class, 'qualifield__employees', 'posted_id', 'rider_id');
    }

    public function AppliedEmployee() {
        return $this->hasMany(AppliedJob::class,'postedjob_id');
    }



     //working

     public function ViewAppliedEmployee(){
      //  ->join('employees', 'employees.user_id', '=', 'applied_jobs.user_id')
     return $this->belongsToMany(User::class, 'applied_jobs', 'postedjob_id', 'user_id');
     }

     public function Answer(){
         return $this->hasManyThrough(User::class,  AppliedJob::class, 'postedjob_id', 'user_id');
     }

     public function EmployeeInfo(){
        return $this->belongsToMany(Post_Job::class, 'applied_jobs', 'postedjob_id', 'user_id');
        }


     public function Employeerelation(){
         return $this->hasOne(Employee::class, 'user_id');
     }

      public function userdata(){
          return $this->hasMany(user::class, );
      }

      public function userinformation(){
          return $this->hasOne(User::class, 'id');
      }

      public function Post_JobSingle() {
        return $this->hasOne(Post_Job::class, 'id');
    }

    public function PaymentOne (){
        return $this->hasOne(Post_Job::class, 'user_id');
    }


}
