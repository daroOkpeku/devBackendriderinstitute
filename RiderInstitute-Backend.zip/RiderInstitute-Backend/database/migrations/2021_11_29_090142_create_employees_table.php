<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateEmployeesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('employees', function (Blueprint $table) {
          $table->id();
          $table->tinyText('name')->nullable();
          $table->tinyText('phone_number')->nullable();
          $table->tinyText('email')->nullable();
          $table->tinyText('date_of_birth')->nullable();
          $table->tinyText('state')->nullable();
          $table->tinyText('lga')->nullable();
          $table->unsignedBigInteger('user_id')->nullable();
          $table->foreign('user_id')->references('id')->on('users');
          $table->tinyText('experience_length')->nullable();
          $table->tinyText('gender')->nullable();
          $table->tinyText('age')->nullable();
          $table->tinyText('role')->nullable();
          $table->tinyText('highest_degree')->nullable();
          $table->longText('skills')->nullable();
          $table->longText('experience')->nullable();
         $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('employees');
    }
}
