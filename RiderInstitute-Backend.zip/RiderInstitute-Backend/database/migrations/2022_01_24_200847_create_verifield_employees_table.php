<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateVerifieldEmployeesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('verifield_employees', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger("employee_id");
            $table->foreign('employee_id')->references('id')->on('users');
            $table->boolean('nin_slippage')->default(0)->nullable();
            $table->boolean('rider_cardpage')->default(0)->nullable();
            $table->boolean('driving_licensepage')->default(0)->nullable();
            $table->boolean('prove_of_addresspage')->default(0)->nullable();
            $table->boolean('passport_photographpage')->default(0)->nullable();
            $table->boolean('status')->default(0)->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('verifield_employees');
    }
}
