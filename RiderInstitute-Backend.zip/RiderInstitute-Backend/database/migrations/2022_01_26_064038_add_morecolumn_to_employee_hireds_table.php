<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddMorecolumnToEmployeeHiredsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('employee_hireds', function (Blueprint $table) {
            $table->boolean('recommend_candiate')->nullable()->default(false);
            $table->boolean('employe_candiate_again')->nullable()->default(false);
            
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('employee_hireds', function (Blueprint $table) {
            //
        });
    }
}
